﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using WinFormTest.Common;
using WinFormTest.Enums;

namespace WinFormTest.ViewController
{
    public partial class ViewImage : Form
    {

        string rootPath = @"D:\Production\PLM\SA";
        public ViewImage()
        {
            InitializeComponent();


            //設定圖示
            this.treeView.ImageList = ImageSetUtil.FileTree();

            //根節點
            TreeNode rootNode = new TreeNode(rootPath, TreeImageEnums.DIRECTORY, TreeImageEnums.DIRECTORY);

            //根節點記錄在tree物件內
            this.treeView.Nodes.Add(rootNode);

            //展所有檔案的樹
            SetDirTreeNode(rootNode, rootPath);

            
            
        }

        /// <summary>
        /// 展所有檔案、資料夾樹
        /// </summary>
        /// <param name="parentNode"></param>
        /// <param name="path"></param>
        public void SetDirTreeNode(TreeNode parentNode, string path)
        {
            //取得資料夾
            string[] dirs = GetDirs(path);
            foreach (string dir in dirs)
            {
                TreeNode dirNode = new TreeNode(dir, TreeImageEnums.DIRECTORY, TreeImageEnums.DIRECTORY);
                parentNode.Nodes.Add(dirNode);

                //遞迴展資料夾內的內容
                string dirPath = path + "/" + dir;
                SetDirTreeNode(dirNode, dirPath);
            }

            //取得檔案
            string[] files = GetFiles(path);
            foreach (string file in files)
            {
                TreeNode fileNode = new TreeNode(file, TreeImageEnums.FILE, TreeImageEnums.FILE);
                parentNode.Nodes.Add(fileNode);
            }
        }


        /// <summary>
        /// 取得資料夾
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string[] GetDirs(string path)
        {

            return Directory.GetDirectories(path)
                .Select(s => s.Substring(s.LastIndexOf("\\") + 1))
                .ToArray();
        }

        /// <summary>
        /// 取得檔名
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string[] GetFiles(string path)
        {

            return Directory.EnumerateFiles(path)
                .Select(s => s.Substring(s.LastIndexOf("\\") + 1))
                .ToArray();
        }
    }
}
