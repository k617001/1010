﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleTest.FileData
{
    public class GetUACFile
    {
        string readPath = @"D:\TestData\GIB\uacFunc2.txt";
        string writePath = @"D:\TestData\GIB\uacFuncTarget2.txt";
        Dictionary<string, string[]> mapData = new Dictionary<string, string[]>();
        public void Action()
        {
            mapData.Add("HEXIAO", new string[] { "HEXIAO", "HEXIAORMA", "HEXIAOTRANS", "HEXIAOGROUP", "HEXIAOWASTAGE", "HEXIAOTRANS_Version" });
            mapData.Add("INPUT", new string[] { "INPUT" });
            mapData.Add("QUERY", new string[] { "QUERY" });
            mapData.Add("QUERYFILES", new string[] { "QUERYFILES" });
            mapData.Add("QUERYINF", new string[] { "QUERYINF" });
            mapData.Add("RMA", new string[] { "RMA", "RMASYSTEM" });
            mapData.Add("TAXQUERY", new string[] { "VendorM", "TransDetail", "TAXQUERY", "TAXQUERYSYSTM", "IMPORTTAX" });
            mapData.Add("UPLOAD", new string[] { "UPLOAD" });
            mapData.Add("UPLOADP", new string[] { "EXPORTQUERY", "UPLOADREF", "UPLOADP", "UPLOADB" });
            mapData.Add("TAXCALCULATE", new string[] { "CALCULATION", "BATCHCALCULATION", "TAXCALCULATE" });
            mapData.Add("CHOOSE", new string[] { "CHOOSE" });
            mapData.Add("JOBDISTRIBUTE", new string[] { "JOBDISTRIBUTE" });


            string result = this.Read();
            Write(result);
        }

        public void Write(string content)
        {
            using (StreamWriter swWriter = new StreamWriter(writePath))
            {
                swWriter.WriteLine(content);
            }
        }

        public string Read()
        {
            StringBuilder result = new StringBuilder();

            using (StreamReader reader = new StreamReader(readPath))
            {
                string line;
                for (int row = 0; (line = reader.ReadLine()) != null; row++)
                {
                    if (row == 0)
                    {
                        result.AppendLine("func_id	EMP_NO	logonid");
                        continue;
                    }

                    string[] column = line.Split('\t');
                    string funcId = column[0];
                    string[] datas = mapData[column[0]];

                    foreach(string data in datas) 
                    {
                        result.AppendLine(line.Replace(funcId, data));
                    }
                } 
            }

            return result.ToString();
        }
    }
}
