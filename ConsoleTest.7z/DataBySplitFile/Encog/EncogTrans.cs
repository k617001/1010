﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Encog.ML.Data;
using Encog.Neural.Networks;
using Encog.Neural.Networks.Layers;
using Encog.Engine.Network.Activation;
using Encog.ML.Data.Basic;
using Encog.ML.Train;
using Encog.Neural.Networks.Training.Propagation.Resilient;
using Encog.Neural.NEAT;
using Encog.Neural.Networks.Training;
using Encog.ML.EA.Train;
using Encog.Util.Simple;
using Encog.Neural.Networks.Training.Propagation.Back;
using Encog.Neural.Networks.Training.Propagation;

namespace ConsoleTest.DataBySplitFile.Encog
{
    public class EncogTrans
    {

        int inputNum = 5;

        public static double[][] Input;
        public static double[][] Ideal;

        public void Action()
        {
            TransMin t = new TransMin(inputNum, new DateTime(2015, 1, 1), new DateTime(2015, 1, 25));

            TransMinObj obj = t.GetTransData();

            double[][] input = obj.TransInputArray();
            double[][] ideal = obj.TransIdealArray();

            Execute(input, ideal);
            
        }

        /// <summary>
        /// Program entry point.
        /// </summary>
        /// <param name="app">Holds arguments and other info.</param>
        public void Execute(double[][] input, double[][] ideal)
        {
            // create a neural network, without using a factory
            BasicNetwork network = new BasicNetwork();
            network.AddLayer(new BasicLayer(null, true, inputNum));
            network.AddLayer(new BasicLayer(new ActivationSigmoid(), true, 4));
            network.AddLayer(new BasicLayer(new ActivationSigmoid(), false, 1));
            network.Structure.FinalizeStructure();
            network.Reset();

            // create training data
            IMLDataSet trainingSet = new BasicMLDataSet(input, ideal);

            // train the neural network using online (batch=1)
            Propagation train = new Backpropagation(network, trainingSet, 0.7, 0.3);
            train.BatchSize = 1;

            int epoch = 1;

            do
            {
                train.Iteration();
                Console.WriteLine(@"Epoch #" + epoch + @" Error:" + train.Error);
                epoch++;
            } while (train.Error > 0.001);

            // test the neural network
            Console.WriteLine(@"Neural Network Results:");
            int i = 0;
            foreach (IMLDataPair pair in trainingSet)
            {
                i++;
                IMLData output = network.Compute(pair.Input);
                double outputActual = output[0];
                double idealVal = pair.Ideal[0];
                double sub = idealVal - outputActual;

                Console.WriteLine(
                        i + @", "
                        + @"actual=" + outputActual + @", "
                        + @"ideal=" + idealVal + @", " 
                        + @"sub=" + sub
                        );
            }
        }
    }
}
