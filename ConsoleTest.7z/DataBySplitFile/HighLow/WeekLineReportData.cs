﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;
using System.Globalization;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 把值規０，所有值減掉開盤價
    /// 把日漲跌的csv資料，變成js檔，畫成highchart
    /// </summary>
    public class WeekLineReportData
    {
        string filePath = @"D:\marketData\TWF_Data\Average\7Day.csv";
        string targetPath = RunAction.HTML_REPORT_DIR + @"Data\";
        string jsName = "WeekLineReportData";

        StringBuilder content = new StringBuilder();

        AveMonthForChart groupChart = new AveMonthForChart();

        public void Action()
        {
            this.LoadDayFile(filePath);

            //寫入至資料js檔案
            ComUtil.CreateDataJsFile(jsName, groupChart.Month, targetPath);

        }

        private void LoadDayFile(string path)
        {
            Console.WriteLine(path);
            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                SetGroup(convert, "yyyy-MM-dd");
            });
        }

        /// <summary>
        /// 設定群組
        /// </summary>
        /// <param name="convert"></param>
        /// <param name="dateFormat"></param>
        /// <param name="group"></param>
        private void SetGroup(
            CSVLoadConvert convert,
            string dateFormat
            )
        {
            string date = convert.GetByIndex<string>(0);
            int close = convert.GetByIndex<int>(1);
            int ave = convert.GetByIndex<int>(2);


            DateTime date2 = DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture);
            string monthDate = date2.ToString("yyyy-MM");


            if (!groupChart.Month.ContainsKey(monthDate))
            {
                groupChart.Month.Add(monthDate, new AveObjForChart());
            }

            AveObjForChart monthObj = groupChart.Month[monthDate];
            monthObj.Date.Add(date);
            monthObj.Close.Add(close);
            monthObj.Ave.Add(ave);

        }


        public class AveMonthForChart
        {
            public AveMonthForChart()
            {
                Month = new Dictionary<string, AveObjForChart>();
            }

            public Dictionary<string, AveObjForChart> Month { set; get; }
        }

        public class AveObjForChart
        {
            public AveObjForChart()
            {
                Date = new List<string>();
                Close = new List<int>();
                Ave = new List<int>();
            }

            public List<string> Date { set; get; }

            public List<int> Close { set; get; }

            public List<int> Ave { set; get; }

        }
    }
}
