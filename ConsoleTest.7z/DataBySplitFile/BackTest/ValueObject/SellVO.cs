﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.Entity;

namespace ConsoleTest.DataBySplitFile.BackTest.ValueObject
{
    public class SellVO
    {
        public ProductInfoVO ProductInfoVO { set; get; }
        public DateTime SellDate { set; get; }
        public int Point { set; get; }
        public int Money { get {
            return Point * ProductInfoVO.PointMoney;
        } }

        public List<BuyVO> BuyVOs { set; get; }

        public NowDataVO NowData { set; get; }
    }
}
