﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using CommonUtil.Helper.CSVLoad;
using ConsoleTest.DataBySplitFile.BackTest.MainData;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data
{


    public class BuyDayData : BuyData
    {
        string connStr = @"D:\marketData\TWF_Data\Average";
        string fileName = @"Buy7Day.csv";

        public BuyDayData(ProductInfoVO productVO)
            : base(productVO)
        {
            base.Init(connStr, fileName);
        }

    }
}
