﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine
{
    public class WeekLineSetting
    {
        public static int DAY = 5;
    }
}
