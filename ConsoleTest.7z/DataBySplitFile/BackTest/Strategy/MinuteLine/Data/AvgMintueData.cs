﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.MainData;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using CommonUtil.Helper.CSVLoad;
using System.Globalization;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine.Data
{
    public class AvgMintueData : AvgData
    {
        string connStr = @"D:\marketData\TWF_Data\Day";
        List<DailyAverageEntity> list = new List<DailyAverageEntity>();
        int minute;
        public AvgMintueData(DateTime dateTime, int minute)
        {
            this.minute = minute;
            base.Init(connStr);

            string fileName = base.csvConn
                .GetFileNames()
                .Where(w => w.Contains(dateTime.ToString("yyyy_MM_dd")))
                .FirstOrDefault();
            base.csvConn.SetRunFileName(fileName);
        }

        /// <summary>
        /// 查詢時先存到記憶體
        /// </summary>
        /// <returns></returns>
        public List<DailyAverageEntity> FindAll()
        {
            if (list.Count > 0)
            {
                return list;
            }

            List<DailyAverageEntity> aveList = new List<DailyAverageEntity>();
            csvConn.Query((idx, convert) =>
            {
                DailyAverageEntity entity = this.ToDailyAvgEntity1(convert);
                aveList.Add(entity);
                list.Add(entity);
                if (aveList.Count > minute)
                {
                    aveList.RemoveAt(0);
                    entity.Average = (int)aveList.Average(a => a.Close);
                }

            });
            return list;
        }

        /// <summary>
        /// 查詢設定的均值
        /// </summary>
        /// <param name="date"></param>
        /// <param name="minute"></param>
        /// <returns></returns>
        public override DailyAverageEntity GetAverage(int nowClose, DateTime nowDateTime)
        {
            return FindAll()
                .Where(w => w.DateTime <= nowDateTime)
                .OrderByDescending(o => o.DateTime)
                .FirstOrDefault();
        }



        /// <summary>
        /// 取得前一筆的資料
        /// </summary>
        /// <param name="nowDateTime"></param>
        /// <returns></returns>
        public override DailyAverageEntity GetBeforeData(DateTime nowDateTime)
        {
            return FindAll()
                .Where(w => w.DateTime < nowDateTime)
                .OrderByDescending(o => o.DateTime)
                .FirstOrDefault();
        }


        private DailyAverageEntity ToDailyAvgEntity1(CSVLoadConvert convert)
        {
            return new DailyAverageEntity()
            {
                DateTime = GetDateTime(convert),
                Close = convert.GetByIndex<int>(5),
                Unit = minute
            };
        }
        private DateTime GetDateTime(CSVLoadConvert convert)
        {
            string dateStr = convert.GetByIndex<string>(0);
            string time = convert.GetByIndex<string>(1);

            string[] timeAry = time.Split(':');

            if (timeAry[0].Length == 1)
            {
                timeAry[0] = "0" + timeAry[0];
            }
            time = timeAry[0] + ":" + timeAry[1];
            return DateTime.ParseExact(dateStr + " " + time, "yyyy/MM/dd HH:mm", CultureInfo.InvariantCulture);

        }
    }
}
