﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using ConsoleTest.DataBySplitFile.BackTest.Base;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using ConsoleTest.DataBySplitFile.BackTest.Enums;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine;
using ConsoleTest.DataBySplitFile.BackTest.MainData;

namespace ConsoleTest.DataBySplitFile.BackTest.MinuteLine.MinuteLineAction
{
    /// <summary>
    /// 週線
    /// </summary>
    public class MinuteLineAction : BaseAvgStrategy
    {

        public MinuteLineAction(
            ProductInfoVO productVO, AvgData avgData, BuyData buyData, SellData sellData)
            : base(productVO, avgData, buyData, sellData)
        {
        }

        public void StrategyAction(NowDataVO data)
        {
            Console.WriteLine(
                data.Date.ToShortDateString() + " " +
                data.Date.ToShortTimeString());
            //取得均線資料

            List<BuyVO> ownData = this.MyOwn();
            DailyAverageEntity avgEntity = base.AvgData.GetAverage(data.Close, data.Date);
            DailyAverageEntity beforeClose = base.AvgData.GetBeforeData(data.Date);

            if (beforeClose == null || avgEntity.Average == 0)
            {
                return;
            }


            //停損點判斷
            if (ownData.Count > 0)
            {
                BuyVO buyOwnVO = ownData[0];


                if (buyOwnVO.Type == BuyTypeEnum.MULTI && buyOwnVO.StopLosePointMulit >= data.Close)
                {
                    Sell(data, ownData, avgEntity, beforeClose);
                }
                if (buyOwnVO.Type == BuyTypeEnum.EMPTY && buyOwnVO.StopLosePointEmpty <= data.Close)
                {
                    Sell(data, ownData, avgEntity, beforeClose);
                }
            }

            int buyType = int.MinValue;
            //做空的交叉
            if (beforeClose.Close > avgEntity.Average && avgEntity.Average > data.Close)
            {
                buyType = BuyTypeEnum.EMPTY;
            }

            //做多的交叉
            else if (beforeClose.Close < avgEntity.Average && avgEntity.Average < data.Close)
            {
                buyType = BuyTypeEnum.MULTI;
            }

            //買賣
            if (buyType != int.MinValue)
            {
                if (ownData != null && ownData.Count > 0)
                {
                    base.Sell(data, ownData, avgEntity, beforeClose);
                }
                base.Buy(data, buyType, avgEntity, beforeClose);
            }
        }


        /// <summary>
        /// 查詢目前未賣掉的資料
        /// </summary>
        /// <returns></returns>
        private List<BuyVO> MyOwn()
        {
            return base.BuyData.FindAll(
                f => 
                    "N".Equals(f.Selled)
                );
        }
    }

}
