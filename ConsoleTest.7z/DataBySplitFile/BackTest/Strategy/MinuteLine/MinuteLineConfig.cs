﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine
{
    public class MinuteLineConfig
    {
        public readonly static string FILE_PATH = @"D:\marketData\TWF_Data\Average\MinuteLine\";
    }
}
