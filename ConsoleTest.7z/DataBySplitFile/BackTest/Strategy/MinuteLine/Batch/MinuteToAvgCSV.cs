﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using CommonUtil;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine.Batch
{
    public class MinuteToAvgCSV
    {
        string targetPath = MinuteLineConfig.FILE_PATH;

        AvgMintueData data = null;
        public MinuteToAvgCSV(ProductInfoVO productVO, DateTime dateTime, int minute)
        {
            data = new AvgMintueData(dateTime, minute);
            string fileName = dateTime.ToString("yyyyMMdd") + "_" + minute + "MinuteAvg.csv";
            targetPath = productVO.GetProductPath(targetPath) + fileName;
        }

        public void Action()
        {
            List<DailyAverageEntity> aveList = data.FindAll();

            StringBuilder content = new StringBuilder();

            int before = 0;
            content.AppendLine("Date,Close,Average,Empty,Muilt,Day,Unit");
            foreach (DailyAverageEntity entity in aveList)
            {

                content.AppendLine(
                    entity.DateTime.ToString("yyyy/MM/dd HH:mm:ss") + "," +
                    entity.Close + "," +
                    entity.Average + "," +
                    (before > 0 && before > entity.Average && entity.Average > entity.Close ? "v" : "") + "," +
                    (before > 0 && before < entity.Average && entity.Average < entity.Close ? "v" : "") + "," +
                    entity.Unit + "," +
                    "minute"
                    );
                before = entity.Close;

            }

            CommonTool.StringToFile(targetPath, content.ToString());
        }
    }
}
