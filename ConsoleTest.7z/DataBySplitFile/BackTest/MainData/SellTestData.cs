﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using ConsoleTest.DataBySplitFile.BackTest.Base;

namespace ConsoleTest.DataBySplitFile.BackTest.MainData
{
    public abstract class SellTestData : BaseData
    {
        string connStr = @"D:\marketData\TWF_Data\Average";
        string fileName = @"Sell7Day.csv";

        string title =
            "BuyPoint,"
            + "AvePoint,"
            + "SellPoint,"
            + "BuyDate,"
            + "SellDate,"
            + "Type,"
            /*
            + "Product,"
            + "Type,"
            + "BackTestId,"
            + "Id1,"
            + "Id2,"
            + "StopLosePointEmpty,"
            + "StopLosePointMulit,"
            + "BuyPoint,"
            + "BuyMoney,"
            + "BuyDate,"
            + "SellPoint,"
            + "SellMoney,"
            + "SellDate,"
            + "addPoint,"
            + "addMoney,"
            + "BuyPointStart,"
            + "BuyPointEnd,"
             * 
             */ 
            ;
        ProductInfoVO productVO;

        public SellTestData(ProductInfoVO productVO)
        {
            this.productVO = productVO;
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="vo"></param>
        /// <param name="type"></param>
        public void Insert(SellVO vo)
        {
            csvConn.Insert(title, ToCsvContent(vo));
        }

        public void DeleteAll()
        {
            csvConn.DeleteAll();
        }

        /// <summary>
        /// 轉成csv文字
        /// </summary>
        /// <param name="vo"></param>
        /// <returns></returns>
        private string ToCsvContent(SellVO vo)
        {
            StringBuilder content = new StringBuilder();
            foreach(BuyVO buyVO in vo.BuyVOs) {

                int getMoney = (vo.Money - buyVO.Money) * buyVO.Type;
                int fee = vo.ProductInfoVO.Fee * buyVO.Type;

                string contenuStr =
                    buyVO.Point + ","
                    + buyVO.AvePoint + ","
                    + vo.Point + ","
                    + buyVO.Date.ToString("yyyy/MM/dd HH:mm:ss") + ","
                    + vo.SellDate.ToString("yyyy/MM/dd HH:mm:ss") + ","
                    + buyVO.Type 

                    /*
                    + vo.ProductInfoVO.Name + ","
                    + buyVO.Type + ","
                    + buyVO.BackTestId.ToString() + ","
                    + buyVO.ID1 + ","
                    + buyVO.ID2 + ","
                    + buyVO.StopLosePointEmpty + ","
                    + buyVO.StopLosePointMulit + ","
                    + buyVO.Point + ","
                    + buyVO.Money + ","
                    + buyVO.Date.ToString("yyyy/MM/dd HH:mm:ss") + ","
                    + vo.Point + ","
                    + vo.Money + ","
                    + vo.SellDate.ToString("yyyy/MM/dd HH:mm:ss") + ","
                    + (vo.Point - buyVO.Point) * buyVO.Type + ","
                    + (vo.Money - buyVO.Money) * buyVO.Type + ","
                    + buyVO.BeforePoint + ","
                    + buyVO.AvePoint*/
                    ;
                content.AppendLine(contenuStr);
            }
            return content.ToString();
        }
    }
}
