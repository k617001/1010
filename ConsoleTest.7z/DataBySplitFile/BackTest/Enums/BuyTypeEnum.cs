﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile.BackTest.Enums
{
    public class BuyTypeEnum
    {
        /// <summary>
        /// 做空
        /// </summary>
        public static int EMPTY = -1;
        /// <summary>
        /// 做多
        /// </summary>
        public static int MULTI = 1;
    }
}
