﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;

namespace ConsoleTest.DataBySplitFile.BackTest.Base
{
    public class BaseData
    {
        protected CsvConnection csvConn = null;

        protected void Init(string connStr)
        {
            csvConn = new CsvConnection(connStr);
        }

        protected void Init(string connStr, string fileName)
        {
            csvConn = new CsvConnection(connStr);
            csvConn.SetRunFileName(fileName);
        }

        protected void Init(string connStr, ProductInfoVO productVO, string fileName)
        {
            csvConn = new CsvConnection(productVO.GetProductPath(connStr));
            csvConn.SetRunFileName(fileName);
        }
    }
}
