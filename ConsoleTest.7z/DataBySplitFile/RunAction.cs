﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile
{
    public class RunAction
    {
        //主要的來源資料
        public static string ALL_SOURCE_DATA = @"D:\marketData\PROG_TWF_1min_Part2_19980722_20150325.txt";

        //目標要存放的資料夾
        public static string TARGET_DIR = @"D:\marketData\TWF_Data\";

        //html chart 資料夾
        public static string HTML_REPORT_DIR = TARGET_DIR + @"Chart_Html\";

        public void Action()
        {
            //new DataSplitFile().Action(); //來源資料切年月日，存放在自訂的資料夾


            //new DayCloseReportData().Action();//每天close集合
            new DayInitReportData().Action();//每天close集合

            /*
            new DayReportData().Action(); //當日所有的chart圖
            new DayInitReportData().Action(); //當日所有的chart圖,用開盤價規０
             * */
            /*
            new DataToCloseHighLow().Action();//取得一天中最高與最低的點，放到一個csv裡
            new DataToCloseHighLowReportData().Action();//最高最低點的html資料


            new DayLimitHighLow().Action();//把每天最高最低點的資料分天放csv中
            new DayLimitHighLowReportData().Action();//每天最高最低點區間的html資料
             * */
        }
    }
}
