﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BallotAiying2;
using System.Drawing;
using CommonUtil;
using System.Drawing.Imaging;
using CommonUtil.Helper.BallotAiying2;
using System.Diagnostics;

namespace ConsoleTest.BallotAiyingTest
{
    public class BaTest
    {
        int gValue = 0;
        public void Action()
        {
            Bitmap bmpobj = new Bitmap(@"D:\555.png");

            for (int i = 0; i <= 255; i++ )
            {
                Stopwatch sw = new Stopwatch();
                sw.Reset();
                sw = Stopwatch.StartNew();
                Console.WriteLine("Start-> " + i);

                gValue = i;
                //灰階化二值化
                Bitmap gv2 = this.Template(bmpobj, GrayValue2);
                //sobel
                Bitmap sobel = this.Sobel(gv2);

                //bmpobj.Save(@"D:\JPG_Test\" + i.ToString().PadLeft(2, '0') + ".jpg", ImageFormat.Png);

                sw.Stop();
                double s = (double)sw.ElapsedMilliseconds / 1000;
                Console.WriteLine("花費 {0} 秒", s);
            }

        }
        public void Action2()
        {
            Bitmap bmpobj = new Bitmap(@"D:\555.png");
            //灰階化二值化
            Bitmap gv2 = this.Template(bmpobj, GrayValue2);

            //sobel
            Bitmap sobel = this.Sobel(gv2);

            sobel.Save(@"D:\JPG_Test\3333.jpg", ImageFormat.Png);

        }



        /// <summary>
        /// sobel
        /// </summary>
        /// <param name="bmpobj"></param>
        /// <param name="runFun"></param>
        /// <returns></returns>
        private Bitmap Sobel2(Bitmap bmpobj)
        {
            ImageHelper image = new ImageHelper();
            int[, ,] rgbData = image.GetRGBData(bmpobj);

            int Width = rgbData.GetLength(0);
            int Height = rgbData.GetLength(1); // 

            int[, ,] rgbData2 = (int[, ,])rgbData.Clone();
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    if (x >= 1 && x < Width - 1 && y >= 1 && y < Height - 1)
                    {
                        int x0 = GetGrayValue2Val(x - 1, y, rgbData2);
                        int x1 = GetGrayValue2Val(x, y, rgbData2);
                        int x2 = GetGrayValue2Val(x + 1, y, rgbData2);

                        int y0 = GetGrayValue2Val(x, y - 1, rgbData2);
                        int y1 = GetGrayValue2Val(x, y, rgbData2);
                        int y2 = GetGrayValue2Val(x, y + 1, rgbData2);

                        if (x0 == 0 && x1 == 0 && x2 == 0
                            && y0 == 0 && y1 == 0 && y2 == 0)
                        {
                            rgbData2[x, y, 0] = 255;
                            rgbData2[x, y, 1] = 255;
                            rgbData2[x, y, 2] = 255;
                        }
                    }
                }
            }

            return image.SetRGBData(rgbData2);
        }


        /// <summary>
        /// 灰階二值化取得值
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="rgbData"></param>
        private int GetGrayValue2Val(int x, int y, int[, ,] rgbData)
        {
            int r = rgbData[x, y, 0]; // Red Channel 保留不動 
            int g = rgbData[x, y, 1]; // Green Channel 改成 0 
            int b = rgbData[x, y, 2]; // Blue Channel 改成 0 

            int value = (int)Math.Round((double)(r + g + b / 3), 0);
            if (value < gValue)
            {
                return 0;
            }
            return 255;
        }

        /// <summary>
        /// sobel
        /// </summary>
        /// <param name="bmpobj"></param>
        /// <param name="runFun"></param>
        /// <returns></returns>
        private Bitmap Sobel(Bitmap bmpobj)
        {
            ImageHelper image = new ImageHelper();
            int[, ,] rgbData = image.GetRGBData(bmpobj);

            int Width = rgbData.GetLength(0);
            int Height = rgbData.GetLength(1); // 

            int[, ,] rgbData2 = (int[, ,])rgbData.Clone();


            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    int r = rgbData2[x, y, 0]; // Red Channel 保留不動 
                    int g = rgbData2[x, y, 1] = 0; // Green Channel 改成 0 
                    int b = rgbData2[x, y, 2] = 0; // Blue Channel 改成 0 

                    int value = (int)Math.Round((double)(r + g + b / 3), 0);
                    if (value < gValue)
                    {
                        rgbData2[x, y, 0] = 0;
                        rgbData2[x, y, 1] = 0;
                        rgbData2[x, y, 2] = 0;
                    }
                    else
                    {
                        rgbData2[x, y, 0] = 255;
                        rgbData2[x, y, 1] = 255;
                        rgbData2[x, y, 2] = 255;
                    }
                }
            }

            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    if (x >= 1 && x < Width-1 && y >= 1 && y < Height-1)
                    {
                        int x0 = rgbData[x - 1, y, 0];
                        int x1 = rgbData[x, y, 0];
                        int x2 = rgbData[x + 1, y, 0];

                        int y0 = rgbData[x, y - 1, 0];
                        int y1 = rgbData[x, y, 0];
                        int y2 = rgbData[x, y + 1, 0];

                        if (x0 == 0 && x1 == 0 && x2 == 0
                            && y0 == 0 && y1 == 0 && y2 == 0)
                        {
                            rgbData2[x, y, 0] = 255;
                            rgbData2[x, y, 1] = 255;
                            rgbData2[x, y, 2] = 255;
                        }
                        else
                        {
                        }
                    }
                }
            }

            return image.SetRGBData(rgbData2);
        }


        /// <summary>
        /// sobel
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="rgbData"></param>
        private void Sobel(Bitmap bitmap, int x, int y, int[, ,] rgbData)
        {
            int width = bitmap.Width;
            int height = bitmap.Width;

            if (x >= 1 && x < width-1)
            {
                int a0 = rgbData[x - 1, y, 0];
                int a1 = rgbData[x, y, 0];
                int a2 = rgbData[x + 1, y, 0];

                if (a0 == 0 && a1 == 0 && a2 == 0)
                {
                    rgbData[x, y, 0] = 255;
                    rgbData[x, y, 1] = 255;
                    rgbData[x, y, 2] = 255;
                }
            }


        }

        
        /// <summary>
        /// 灰階二值化合併
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="rgbData"></param>
        private void GrayValue2(Bitmap bitmap, int x, int y, int[, ,] rgbData)
        {
            int r = rgbData[x, y, 0]; // Red Channel 保留不動 
            int g = rgbData[x, y, 1] = 0; // Green Channel 改成 0 
            int b = rgbData[x, y, 2] = 0; // Blue Channel 改成 0 

            int value = (int)Math.Round((double)(r + g + b / 3), 0);
            if (value < gValue)
            {
                rgbData[x, y, 0] = 0;
                rgbData[x, y, 1] = 0;
                rgbData[x, y, 2] = 0;
            }
            else
            {
                rgbData[x, y, 0] = 255;
                rgbData[x, y, 1] = 255;
                rgbData[x, y, 2] = 255;
            }
        }

        /// <summary>
        /// 二值化
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="rgbData"></param>
        private void Value2(Bitmap bitmap, int x, int y, int[, ,] rgbData)
        {
            int value = rgbData[x, y, 0];//灰階化後三個值都一樣
            if (value < 128)
            {
                rgbData[x, y, 0] = 0;
                rgbData[x, y, 1] = 0;
                rgbData[x, y, 2] = 0;
            }
            else
            {
                rgbData[x, y, 0] = 255;
                rgbData[x, y, 1] = 255;
                rgbData[x, y, 2] = 255;
            }

        }

        /// <summary>
        /// 灰階化
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="rgbData"></param>
        private void Gray(Bitmap bitmap, int x, int y, int[, ,] rgbData)
        {
            int r = rgbData[x, y, 0]; // Red Channel 保留不動 
            int g = rgbData[x, y, 1] = 0; // Green Channel 改成 0 
            int b = rgbData[x, y, 2] = 0; // Blue Channel 改成 0 

            int value = (int)Math.Round((double)(r + g + b / 3), 0);
            rgbData[x, y, 0] = value;
            rgbData[x, y, 1] = value;
            rgbData[x, y, 2] = value;
        }



        /// <summary>
        /// 主要執行
        /// </summary>
        /// <param name="bmpobj"></param>
        /// <param name="runFun"></param>
        /// <returns></returns>
        private Bitmap Template(Bitmap bmpobj, Action<Bitmap, int, int, int[, ,]> runFun)
        {
            ImageHelper image = new ImageHelper();
            int[, ,] rgbData = image.GetRGBData(bmpobj);

            int Width = rgbData.GetLength(0);
            int Height = rgbData.GetLength(1); // 
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    runFun(bmpobj, x, y, rgbData);
                }
            }

            return image.SetRGBData(rgbData);
        }
    }
}
