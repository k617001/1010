﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace ConsoleTest.Reflection
{
    public class ReflectionTest
    {
        public void Action()
        {
            Type t = Type.GetType("ConsoleTest.Reflection.User");

            t.GetMethod("Test2", BindingFlags.NonPublic | BindingFlags.Static).Invoke(null, new Object[] { "1234" });
        }
    }

    public class User
    {
        public void Test(string x)
        {
        }

        private static void Test2(string x)
        {
            Console.WriteLine(x);
        }
    }
}
