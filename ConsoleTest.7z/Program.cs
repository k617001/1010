﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ObjectContainer;
using ConsoleTest.BusinessLogic.Register;
using ConsoleTest.BusinessLogic.Interface;
using System.IO;
using System.Globalization;
using ConsoleTest.extandAAA;
using System.Text.RegularExpressions;
using CommonUtil.Util.ConvertObject;
using CommonUtil.Helper.CSVLoad;
using ConsoleTest.FindFileString;
using ConsoleTest.BusinessLogic.Implement;
using ConsoleTest.DataBySplitFile;
using ConsoleTest.EqualsFileContent;
using ConsoleTest.ThreadTest;
using ConsoleTest.MapTest;
using ConsoleTest.DataBySplitFile.Encog;
using ConsoleTest.DataTableTest;
using ConsoleTest.ExcelTest;
using NPOI.XSSF.UserModel;
using ConsoleTest.Reflection;
using ConsoleTest.AdoNetBatch;
using ConsoleTest.QlearningTest;
using ConsoleTest.BallotAiyingTest;
using System.Collections;
using ConsoleTest.DataBySplitFile.TickConvert;
using ConsoleTest.leetCode.Program;
using ConsoleTest.FileData;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Batch;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine;

namespace ConsoleTest
{


    class Program
    {

        static void Main(string[] args)
        {
           //new ToAvgCSVBatchAction().Action();
           //new WeekLineReportData().Action();


            new MinuteLineActionTest().Action();
            /*
            new TickToData().Action();
            new DayCloseReportData().Action();
            */
        }



        /// <summary>
        /// 數字判斷，小數點到三位，不含負號
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static bool IsNumber(string number)
        {
            string pattern = "^[0-9]+(.[0-9]{0,3})?$";
            Regex reg = new Regex(pattern);
            return reg.IsMatch(number);
        }
    }
}
