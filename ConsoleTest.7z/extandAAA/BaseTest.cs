﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.extandAAA
{
    public abstract class BaseTest
    {
        public abstract void Aaaa();
    }
}
