﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Helper.DBHelper.DBComponent
{
    interface IDBComponent
    {
        int Insert<T>(T entity);

        int Update<T>(T entity);

        int Delete<T>(T entity);

        void Execute(string sql, Dictionary<string, object> param);

        int Commit();

        List<T> FindList<T>(string sql, Dictionary<string, object> param);

        List<T> FindList<T>(string sql);

        T FindByPK<T>(string sql, Dictionary<string, object> param);

        T FindByPK<T>(string sql);


    }
}
