﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Case1.ValueObject;

namespace CommonUtil.Case1.Anslysis
{
    public abstract class BaseMain
    {
        protected List<ResultVO> resultList = new List<ResultVO>();


        public List<ResultVO> Result()
        {
            this.DataAnalysis();
            return resultList;
        }

        /// <summary>
        /// 分析方法
        /// </summary>
        public abstract void DataAnalysis();
    }
}
