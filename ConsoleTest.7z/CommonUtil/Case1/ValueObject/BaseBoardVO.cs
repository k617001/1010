﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Case1.ValueObject
{
    public class BaseBoardVO
    {
        public double Width { set; get; }

        public double Height { set; get; }

        public string ID { set; get; }


        /// <summary>
        /// 基本資訊
        /// </summary>
        /// <returns></returns>
        public string Info()
        {
            return this.ID + "(" + this.Width + " * " + this.Height + " )";
        }

        /// <summary>
        /// 取得面積
        /// </summary>
        public double Area
        {
            get
            {
                return this.Width * this.Height;

            }
        }

        /// <summary>
        /// 將長寬依標準拉成同一維度，
        /// 超過或不符合則回傳false
        /// </summary>
        /// <param name="standardWidth"></param>
        /// <returns></returns>
        public bool SetStandardWH(double standardLength)
        {
            double tmpWidth = standardLength - this.Width;
            double tmpHeight = standardLength - this.Height;

            if (tmpWidth < 0 || tmpHeight < 0)
            {
                return false;
            }

            StandardWidth = this.Width;
            StandardHeight = this.Height;

            if (tmpHeight < tmpWidth)
            {
                StandardWidth = this.Height;
                StandardHeight = this.Width;
            }


            return true;
        }

        /// <summary>
        /// 標準寬度
        /// </summary>
        public double StandardWidth { set; get; }


        /// <summary>
        /// 標準長度
        /// </summary>
        public double StandardHeight { set; get; }

    }
}
