﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Case1.Run;
using CommonUtil.Case1.Run.Data;
using CommonUtil.Case1.ValueObject;
using CommonUtil.Case1.Output;

namespace CommonUtil.Case1
{
    public class CaseRun
    {
        public void Action()
        {
            //設定相關資料
            DataAcess.SetData();

            //分析資料
            List<ResultVO> results = AnalysisResult.GetForMainBox();

            //結果
            OutputResult.Output(results);
        }
    }
}
