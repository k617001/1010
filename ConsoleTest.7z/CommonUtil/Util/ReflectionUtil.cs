﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace CommonUtil.Util
{
    public class ReflectionUtil
    {
        /// <summary>
        /// 反射設定值
        /// </summary>
        /// <typeparam name="T">寫入值的物件</typeparam>
        /// <param name="propertyName">欄位名</param>
        /// <param name="value"></param>
        /// <param name="obj"></param>
        public static void SetValue<T>(PropertyInfo property, object value, T obj) 
        {
        }
    }
}
