﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.leetCode.Program
{
    public class LeetCodeAction
    {
        public void Action()
        {
            (new RemoveDuplicatesSortArray()).Action();
            //(new RemoveDuplicatesSortArray2()).Action();
        }
    }
}
