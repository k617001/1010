﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.leetCode
{
    /// <summary>
    /*
    Follow up for "Remove Duplicates": What if duplicates are allowed at most twice?
    For example, Given sorted array A = [1,1,1,2,2,3],
    Your function should return length = 5, and A is now [1,1,2,2,3].
    移除重复的元素，但是可以允许最多两次重复元素存在。
     */
    /// </summary>
    public class RemoveDuplicatesSortArray2
    {
        
        public void Action()
        {
            int[] a = { 1, 1, 1, 2, 2, 3, 3 };

            int len = RemoveDuplicates(a, a.Length);
        }

        public int RemoveDuplicates(int[] a, int n)
        {
            if (n == 0)
            {
                return n;
            }

            int dupCountLimit = 2;
            int dupCount = 0;
            int j = 0;
            int nowValue = a[j];
            for (int i = 1; i < a.Length; i++)
            {
                if (nowValue != a[i])
                {
                    a[j] = a[i];
                    nowValue = a[i];
                    j++;
                    dupCount = 1;
                }
                else if (i == 1 || dupCount < dupCountLimit)
                {
                    a[j++] = nowValue;
                    dupCount++;
                }
            }

            return j;
        }
    }
}
