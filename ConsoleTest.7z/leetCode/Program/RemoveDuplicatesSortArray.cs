﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.leetCode
{
    /// <summary>
    /// Given a sorted array, remove the duplicates in place such that > each element appear only once and return the new length.
    /// Do not allocate extra space for another array, you must do this in place with constant memory.
    /// For example, Given input array A = [1,1,2],
    /// Your function should return length = 2, and A is now [1,2].
    /// </summary>
    public class RemoveDuplicatesSortArray
    {
        
        public void Action()
        {
            int[] a = { 1, 1, 1, 2, 2, 2, 2, 2, 3, 4, 4, 4 };

            int len = RemoveDuplicates(a, a.Length);
        }

        public int RemoveDuplicates(int[] a, int n)
        {
            if(n == 0) 
            {
                return n;
            }

            int j = 0;
            int nowValue = a[j];
            for (int i = 1; i < a.Length; i++ )
            {
                if (nowValue != a[i])
                {
                    a[j] = a[i];
                    nowValue = a[i];
                    j++;
                }
                else if (i == 1)
                {
                    a[j++] = nowValue;
                }
            }

            return j;
        }
    }
}
