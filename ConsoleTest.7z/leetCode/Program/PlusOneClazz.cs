﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.leetCode.Program
{
    /// <summary>
    /// Given a non-negative number represented as an array of digits, plus one to the number.
    /// The digits are stored such that the most significant digit is at the head of the list.
    /// </summary>
    public class PlusOneClazz
    {
        public void Action()
        {
        }


    }
}
