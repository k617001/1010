﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleTest.EqualsFileContent
{
    public class EqualsFile
    {
        public void Action()
        {
            string sourceFile = @"D:\BeforeUpdate.txt";
            string targetFile = @"D:\AfterUpdate.txt";

            string sourceStr = this.GetContent(sourceFile);
            string targetStr = this.GetContent(targetFile);

            string[] source = sourceStr.Split('\n');
            string[] target = targetStr.Split('\n');

            for (int i = 0; i < source.Length; i++ )
            {
                string sourceLine = source[i];
                string targetLine = target[i];

                if (!sourceLine.Equals(targetLine))
                {
                    Console.WriteLine(i + "=> not equal");
                }
            }

            Console.Write(sourceStr.Equals(targetStr));
        }

        public string GetContent(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                return sr.ReadToEnd();
            }
        }
    }
}
