﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace ConsoleTest.DataTableTest
{
    public class SearchData
    {
        public void Action()
        {
            string qrySQL = @"
select 
    *
from
    dbo.Alert_List
where
    sn = 1            
            ";

            DataTable result = FindBySQL(qrySQL);


            foreach (DataColumn column in result.Columns)
            {
                Console.WriteLine(column.ColumnName + "->" + column.AutoIncrement);
            }
        }

        private DataTable FindBySQL(string qrySQL)
        {

            string connStr = "Database=BriViewDQA;Server=fhtwdbt01;uid=PLM.AP;pwd=plm@AP";

            DataTable result = new DataTable();
            using (SqlConnection connection = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(qrySQL, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(result);
                    }
                }
            }
            return result;
        }
    }
}
