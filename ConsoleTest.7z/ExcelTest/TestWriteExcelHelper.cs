﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.UserModel;
using CommonUtil.Helper.ExcelHelper;
using System.IO;

namespace ConsoleTest.ExcelTest
{
    public class TestWriteExcelHelper
    {
        public void Action()
        {
            string path = @"D:\Test\TestExl.xlsx";


            ExcelWriterHelper helper = new ExcelWriterHelper();
            IWorkbook workbook = helper.SetWorkBook(path);

            ISheet sheet = workbook.GetSheetAt(0);
            helper.SetSheet(sheet);

            helper.SetRowIndex(8);
            for(int i = 0; i < 10; i++) {
                helper.SetCellValue(i);
            }

            helper.SaveTo(@"D:\Test\TestExl111.xlsx");
        }
    }
}
