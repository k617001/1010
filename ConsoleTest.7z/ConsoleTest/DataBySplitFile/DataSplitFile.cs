﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    public class DataSplitFile
    {
        string filePath = @"D:\marketData\PROG_TWF_1min_Part2_19980722_20150325.txt";
        string targetDir = @"D:\marketData\TWF_Data\";


        string dateFormat = string.Empty;
        string prefixFileName = string.Empty;

        public void Action()
        {
            //展年的資料
            this.dateFormat = "yyyy";
            this.prefixFileName = "Year";
            Start();

            //展月的資料
            this.dateFormat = "yyyy_MM";
            this.prefixFileName = "Month";
            Start();

            //展日的資料
            this.dateFormat = "yyyy_MM_dd";
            this.prefixFileName = "Day";
            Start();
        }


        public void Start() 
        {
            bool isFirst = true;
            string title = null;
            string dataSplit = string.Empty;
            StringBuilder content = new StringBuilder();
            int dataCount = 0;

            CSVLoadHelper.LoadCsv(filePath, (row, convert) =>
            {
                if(title == null) 
                {
                    title = convert.GetTitleLine();
                }

                string date = convert.Get<string>("date");
                string time = convert.Get<string>("time");
                string dt = date + " " + (time.Length > 5 ? time : time + ":00");
                DateTime dateTime = Convert.ToDateTime(dt);

                string tmeDataSp = dateTime.ToString(dateFormat);

                if (!dataSplit.Equals(tmeDataSp))
                {
                    //第一次不執行
                    if (!isFirst)
                    {
                        Console.WriteLine("執行 " + dataCount + " 筆");
                        CreateFile(content, dataSplit);
                    }
                    dataCount = 0;//寫入檔案規0
                    dataSplit = tmeDataSp;//換下一種資料型態
                    content.AppendLine(title);//寫入title
                    isFirst = false;//設定第一次不執行的flag為false
                }

                dataCount++;
                content.AppendLine(convert.GetDataLine());
            });


            Console.WriteLine("執行 " + dataCount + " 筆");
            CreateFile(content, dataSplit);
        }

        private void CreateFile(StringBuilder content, string tmeDataSp)
        {
            string dirPath = targetDir + prefixFileName;
            string fileName = tmeDataSp + ".csv";
            string filePath = dirPath + fileName;

            Console.WriteLine("檔案： " + filePath);

            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }

            ComUtil.Str2File(content.ToString(), filePath);
            content.Clear();
        }

    }
}
