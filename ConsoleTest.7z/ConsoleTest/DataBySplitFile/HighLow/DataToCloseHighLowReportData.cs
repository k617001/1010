﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 把日漲跌的csv資料，變成js檔，畫成highchart
    /// </summary>
    public class DataToCloseHighLowReportData
    {
        string filePath = @"D:\marketData\TWF_Data\analysis\MaxMinValue_day.csv";
        string targetPath = @"D:\marketData\TWF_Data\Chart_Html\Data\";

        StringBuilder content = new StringBuilder();

        MaxMinObjGroupForChart groupChart = new MaxMinObjGroupForChart();

        public void Action()
        {
            CSVLoadHelper.LoadCsv(filePath, (row, convert) =>
            {
                SetGroup(convert, "yyyy", groupChart.Year);
                SetGroup(convert, "yyyy_MM", groupChart.Month);
            });

            //寫入至資料js檔案
            ComUtil.CreateDataJsFile("MaxMinValueSumData_Year", groupChart.Year, targetPath);
            ComUtil.CreateDataJsFile("MaxMinValueSumData_Month", groupChart.Month, targetPath);

        }

        /// <summary>
        /// 設定群組
        /// </summary>
        /// <param name="convert"></param>
        /// <param name="dateFormat"></param>
        /// <param name="group"></param>
        private void SetGroup(
            CSVLoadConvert convert,
            string dateFormat,
            Dictionary<string, MaxMinObjForChart> groupMap
            )
        {
            DateTime dateTime = convert.Get<DateTime>("date");
            string groupName = dateTime.ToString(dateFormat);

            MaxMinObjForChart chartData = null;
            if (!groupMap.ContainsKey(groupName))
            {
                groupMap.Add(groupName, new MaxMinObjForChart());
            }
            chartData = groupMap[groupName];

            chartData.Date.Add(dateTime.ToString("yyyy-MM-dd"));
            chartData.Highest.Add(convert.Get<int>("Highest"));
            chartData.Lowest.Add(convert.Get<int>("Lowest"));
        }


        public class MaxMinObjGroupForChart
        {
            public MaxMinObjGroupForChart()
            {
                Year = new Dictionary<string, MaxMinObjForChart>();
                Month = new Dictionary<string, MaxMinObjForChart>();
            }

            public Dictionary<string, MaxMinObjForChart> Year { set; get; }

            public Dictionary<string, MaxMinObjForChart> Month { set; get; }
        }

        public class MaxMinObjForChart
        {
            public MaxMinObjForChart()
            {
                Date = new List<string>();
                Highest = new List<int>();
                Lowest = new List<int>();
            }

            public List<string> Date { set; get; }

            public List<int> Highest { set; get; }

            public List<int> Lowest { set; get; }
        }
    }
}
