﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 抓當日最高和最低點中所有的資料
    /// </summary>
    public class DayLimitHighLow
    {
        string analysisFilePath = @"D:\marketData\TWF_Data\analysis\MaxMinValue_day.csv";
        string filePath = @"D:\marketData\TWF_Data\Day\";
        string targetPath = @"D:\marketData\TWF_Data\analysis\HighLowLimit_day.csv";

        StringBuilder content = new StringBuilder();

        string title = null;

        public void Action()
        {
            CSVLoadHelper.LoadCsv(analysisFilePath, (row, convert) =>
            {
                SetToFile(convert);
            });
            
        }

        private void SetToFile(CSVLoadConvert convert)
        {




            Console.WriteLine(dateStr);
            SetData(date + dateStr + ".csv", convert);

            ComUtil.Str2File(content.ToString(), targetPath);
        }


        private void SetData(string path, CSVLoadConvert limitConvert)
        {
            DateTime l = limitConvert.Get<DateTime>("Date");
            string dateStr = date.ToString("yyyy/MM/dd");

            int highest = limitConvert.Get<int>("Highest");
            DateTime highestTime = limitConvert.Get<DateTime>("HighestTime");
            int lowest = limitConvert.Get<int>("Lowest");
            DateTime lowestTime = limitConvert.Get<DateTime>("LowestTime");

            DateTime sDate = highestTime > lowestTime ? lowestTime : highestTime;
            DateTime eDate = highestTime < lowestTime ? lowestTime : highestTime;

           
            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                if (title == null)
                {
                    title = convert.GetTitleLine();
                }

                string date = convert.Get<string>("date");
                string time = convert.Get<string>("time");
                string dt = date + " " + (time.Length > 5 ? time : time + ":00");
                DateTime dateTime = Convert.ToDateTime(dt);

                int close = convert.Get<int>("Close");

                if (dateTime < sDate || dateTime > eDate)
                {
                    return;
                }

                content.AppendLine(convert.GetDataLine());

            });

            SaveData(string fileName)
        }

        private void SaveData(string fileName)
        {
        }
    }

}
