﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace ConsoleTest.FindFileString
{
    /// <summary>
    /// 查詢檔案內容
    /// </summary>
    public class FindFileContent
    {
        string rootPath = @"D:\Production\PLM\GPARS\GPARS_BRIVIEW";//資料夾-會抓所有子資料夾來掃
        string findString = "Green Part Approval / 綠色零件承認申請單";//要找的字串
        string findExFileName = ".aspx";//副檔名

        //設定
        bool isConsoleShowFile = false;//是否要顯示已掃過的檔案
        bool isConsoleShowFolder = false;//是否要顯示已掃過的資料夾

        List<string> findStringList = new List<string>();//記錄找到的路徑

        /// <summary>
        /// 主要執行方法
        /// </summary>
        public void Action()
        {
            FindFolder(rootPath);

            //顯示結果
            Console.WriteLine("--------------------------------------------------------");
            foreach (string str in findStringList)
            {
                Console.WriteLine(str);
            }
        }

        private void FindFolder(string rootPath) {

            FindFileStr(rootPath);

            string[] dirFolders = Directory.GetDirectories(rootPath);

            foreach (string dir in dirFolders)
            {
                if (isConsoleShowFolder)
                {
                    Console.WriteLine(dir);
                }
                
                FindFolder(dir);
            }
        }

        private void FindFileStr(string rootPath)
        {
            string[] dirFiles = Directory
                .GetFiles(rootPath)
                .Where(w => Regex.Match(w, findExFileName, RegexOptions.IgnoreCase).Success)
                .ToArray()
                ;

            foreach (string dirPath in dirFiles)
            {
                string content = this.GetFileString(dirPath);
                bool isContain = Regex.Match(content, findString, RegexOptions.IgnoreCase).Success;

                if (isConsoleShowFile)
                {
                    Console.WriteLine(dirPath);
                }
                

                if (isContain)
                {
                    findStringList.Add(dirPath);
                }
            }
        }

        private string GetFileString(string folderPath)
        {
            StringBuilder content = new StringBuilder();
            using (StreamReader sr = new StreamReader(folderPath))
            {
                content.Append(sr.ReadToEnd());
            }

            return content.ToString();
        }
    }
}
