﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ObjectContainer;
using ConsoleTest.BusinessLogic.Register;
using ConsoleTest.BusinessLogic.Interface;
using System.IO;
using System.Globalization;
using ConsoleTest.extandAAA;
using System.Text.RegularExpressions;
using CommonUtil.Util.ConvertObject;
using CommonUtil.Helper.CSVLoad;
using ConsoleTest.FindFileString;
using ConsoleTest.BusinessLogic.Implement;
using ConsoleTest.DataBySplitFile;

namespace ConsoleTest
{
    class Program
    {

        static void Main(string[] args)
        {

            new DataSplitFile().Action();

            //統計用
            new DataToCloseHighLow().Action();
            new DataToCloseHighLowReportData().Action();

            /*
            Container containerType = new Container();
            RegisterBL.Register(containerType);

            
            
            DateTime ddd = DateTime.ParseExact("20170101",
                                  "yyyyMMdd",
                                   CultureInfo.InvariantCulture);

            CultureInfo ci = CultureInfo.CurrentCulture;
            Calendar cd = ci.Calendar;
            Int32 weekcode = cd.GetWeekOfYear(ddd, CalendarWeekRule.FirstDay, DayOfWeek.Monday) - 1;
            Console.Write(weekcode);
             * 
             * i  j j%i+1 j/i i-j
             * 1  1  0     1   0 
             * 2  1  1     0   1
             * 2  2  0     1   0
             * 3  1  1     0   2
             * 3  2  2     0   1
             * 3  3  0     1   0
             * 4  1  1     0   3
             * 4  2  2     0   2
             * 4  3  3     0   1
             * 4  4  0     1   0
             * */

            
           // (new FindFileContent()).Action();
            /*
            for (int i = 1, j = 1; i <= 9; i+=j/9, j=j%i+1)
            {
                Console.Write(i + "x" + j + "=" + i*j);
                Console.WriteLine();
            }
            
            int i = 1;
            int j = 1;
            while(i <= 9) {

                j = j % i + 1;
                i += j / i;

                Console.Write("x");
            }*/
            //string[] x = "aaaaaa,bb".Split(',');

            /*
             * 0001 ^ 0101 = 0100(1^5=4->a^b=a)
             * 0100 ^ 0101 = 0001(4^5=1->a^b=b)
             * 0001 ^ 0100 = 0101(1^4=5->a^b=a)
             * 
             * 
             * 0001
             * 0101
             * 0100
             * 
             * 0100
             * 0101
             * 0001
             * 
             * 0001
             * 0100
             * 0101
             * 
             * */

            /*
            int a = 9999;
            int b = 8888;

            a = a ^ b;
            b = a ^ b;
            a = a ^ b;


            object x = 1;
            Type type = x.GetType();
             */ 
        }

        /// <summary>
        /// 數字判斷，小數點到三位，不含負號
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static bool IsNumber(string number)
        {
            string pattern = "^[0-9]+(.[0-9]{0,3})?$";
            Regex reg = new Regex(pattern);
            return reg.IsMatch(number);
        }
    }
}
