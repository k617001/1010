﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleTest.TableSchemaHtml.Common
{
    public class DBHelper
    {
        string connStr = null;
        public DBHelper(string connStr)
        {
            this.connStr = connStr;
        }

        /// <summary>
        /// 查詢方法
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns></returns>
        public DataTable Search(string qrySQL, Dictionary<string, object> param)
        {
            DataTable dataResult = null;

            using(SqlConnection sqlConn = new SqlConnection(this.connStr)) {
                using (SqlCommand cmd = new SqlCommand(qrySQL, sqlConn))
                {
                    cmd.CommandType = CommandType.Text;

                    if (param != null && param.Count > 0)
                    {
                        this.SetParam(cmd, param);
                    }
                }
            }

            return dataResult;
        }

        /// <summary>
        /// 設定參數
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="param"></param>
        private void SetParam(SqlCommand cmd, Dictionary<string, object> param)
        {
            foreach(string key in param.Keys) {
                cmd.Parameters.Add(new SqlParameter(key, param[key]));
            }
        }
    }
}
