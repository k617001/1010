﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ObjectContainer;

namespace ConsoleTest.BusinessLogic.Register
{
    public class FactoryBL
    {
        public static T GetInstance<T>()
        {
            return Container.GetInstance<T>();
        }
    }
}
