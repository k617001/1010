﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.BusinessLogic.Interface;

namespace ConsoleTest.BusinessLogic.Implement
{
    public class EmployeeBL : IEmployeeBL
    {
        public void Test()
        {
            Console.WriteLine(@"Test1");
        }
    }
}
