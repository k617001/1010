﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.BusinessLogic.Interface;

namespace ConsoleTest.BusinessLogic.Implement
{
    public class Employee2BL : IEmployeeBL
    {
        IEmployeeBL x;
        public Employee2BL(IEmployeeBL x)
        {
            this.x = x;
        }

        public void Test()
        {
            Console.WriteLine(@"Test2");
        }
    }
}
