﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace ConsoleTest.FindFileString
{
    /// <summary>
    /// 查詢檔案內容
    /// </summary>
    public class FindFileContent
    {
        string rootPath = @"D:\Production\GIB\GIBPortal_2010";//資料夾-會抓所有子資料夾來掃
        string findString = @"GIBPortal\\";//要找的字串
        string findExFileName = "*";//副檔名

        //設定
        bool isConsoleShowFile = false;//是否要顯示已掃過的檔案
        bool isConsoleShowFolder = true;//是否要顯示已掃過的資料夾
        bool isFindShow = true;//比對到就馬上show出來
        bool isOnlyFindFolderName = true;//只查詢資料夾名稱，不查詢檔案

        List<string> findStringList = new List<string>();//記錄找到的路徑

        string logPath = @"D:\SEARCH_LOG.log";

        /// <summary>
        /// 主要執行方法
        /// </summary>
        public void Action()
        {
            FindFolder(rootPath);

            //顯示結果
            Console.WriteLine("--------------------------------------------------------");

            //寫到log檔
            using (StreamWriter searchLog = new StreamWriter(logPath))
            {
                foreach (string str in findStringList)
                {
                    searchLog.WriteLine(str);
                    Console.WriteLine(str);
                }
            }
        }

        /// <summary>
        /// 只找資料夾
        /// </summary>
        /// <param name="rootPath"></param>
        private void OnlyFindFolder(string rootPath)
        {
            string[] dirFolders = Directory.GetDirectories(rootPath);

            foreach (string dir in dirFolders)
            {

                if (Regex.Match(dir, findString, RegexOptions.IgnoreCase).Success)
                {
                    Console.WriteLine(dir);
                    findStringList.Add(dir);
                }
                OnlyFindFolder(dir);
            }
        }

        /// <summary>
        /// 一般查詢
        /// </summary>
        /// <param name="rootPath"></param>
        private void FindFolder(string rootPath) 
        {
            //只查詢資料夾的執行
            if (isOnlyFindFolderName)
            {
                OnlyFindFolder(rootPath);
                return;
            }

            FindFileStr(rootPath);
            string[] dirFolders = Directory.GetDirectories(rootPath);

            foreach (string dir in dirFolders)
            {
                if (isConsoleShowFolder)
                {
                    Console.WriteLine(dir);
                }
                
                FindFolder(dir);
            }
        }

        private void FindFileStr(string rootPath)
        {
            string[] dirFiles = Directory
                .GetFiles(rootPath)
                .Where(w => Regex.Match(w, findExFileName, RegexOptions.IgnoreCase).Success)
                .ToArray()
                ;

            foreach (string dirPath in dirFiles)
            {
                string content = this.GetFileString(dirPath);
                bool isContain = Regex.Match(content, findString, RegexOptions.IgnoreCase).Success;

                if (isConsoleShowFile)
                {
                    Console.WriteLine(dirPath);
                }
                

                if (isContain)
                {
                    if (isFindShow)
                    {
                        Console.WriteLine(dirPath);
                    }

                    findStringList.Add(dirPath);
                }
            }
        }

        private string GetFileString(string folderPath)
        {
            StringBuilder content = new StringBuilder();
            using (StreamReader sr = new StreamReader(folderPath))
            {
                content.Append(sr.ReadToEnd());
            }

            return content.ToString();
        }
    }
}
