﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.QlearningTest
{
    public class Flow2Data
    {



        public int[,] Reward(List<string[]> sample, int goalIdx)
        {
            int[,] reward = InitData(sample.Count);

            SetData(sample, goalIdx, reward);

            Display(reward);
            return reward;
        }


        private void Display(int[,] array)
        {
            ConsoleColor color = Console.ForegroundColor;
            for (int i = 0; i <= array.GetUpperBound(0); i++)
            {
                for (int ii = 0; ii <= array.GetUpperBound(1); ii++)
                {
                    if (array[i, ii] > 0)
                        Console.ForegroundColor = ConsoleColor.Red;
                    int len = (array[i, ii].ToString()).Length;
                    string empty = string.Empty.PadRight(4 - len);
                    Console.Write(array[i, ii] + empty);
                    Console.ForegroundColor = color;

                }
                Console.WriteLine();
            }

            Console.WriteLine();
        }

        public void SetData(List<string[]> sample, int goalIdx, int[,] reward)
        {
            foreach(string[] idxData in sample) 
            {
                foreach(string idxIO in idxData) 
                {
                    string[] idxAry = idxIO.Split(',');
                    int row = Convert.ToInt32(idxAry[0]);
                    int column = Convert.ToInt32(idxAry[1]);

                    int value = 0;
                    if (column == goalIdx)
                    {
                        value = 100;
                    }

                    reward[row, column] = value;
                }
            }
        }

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        private int[,] InitData(int size)
        {
            int[,] reward = new int[size, size];

            for (int row = 0; row < size; row++)
            {
                for (int column = 0; column < size; column++)
                {
                    reward[row, column] = -1;
                }
            }
            return reward;
        }
    }
}
