﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.QlearningTest
{
    public class TestQ
    {

        public void Action()
        {
            int goalIdx = 5;
            List<string[]> sample = new List<string[]>()
            {
                new string[]{"0,4"},
                new string[]{"1,3", "1,5"},
                new string[]{"2,3"},
                new string[]{"3,1", "3,2", "3,4"},
                new string[]{"4,0", "4,3", "4,5", "4, 6"},
                new string[]{"5,1", "5,4", "5,5"},
                new string[]{"6,7", "6,4"},
                new string[]{"7,6"},

            };

            Flow2Data flowData = new Flow2Data();
            int[,] reward = flowData.Reward(sample, goalIdx);

            Qlearning ql = new Qlearning();
            ql.Action(0.8, reward);
        }
    }
}
