﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ChessCore.WalkPoint.Walk;

namespace CommonUtil.ChessCore.Walk
{
    public class WalkFactory
    {
        private static Dictionary<ChessEnums, IWalk> walkMap = new Dictionary<ChessEnums, IWalk>();
        public static void Register() 
        {

            walkMap.Add(ChessEnums.KING, new KingWalkPoint());
            walkMap.Add(ChessEnums.FOUR, new FourWalkPoint());
                
        }

        public static IWalk GetWalkInstance(ChessEnums type)
        {
            return walkMap[type];
        }
    }
}
