﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ChessCore.Walk;

namespace CommonUtil.ChessCore.WalkPoint.Walk
{
    public class ElementWalkPoint : IWalk
    {
        public ChessPoint CreateStartPoint(bool isRight, bool isStart)
        {

            int x = isRight ? 2 : 6;
            int y = isStart ? 0 : 7;
            return new ChessPoint(x, y);
        }

        public IEnumerable<ChessPoint> CanWalkPoint(ChessObj chess)
        {
            int startX = 0;
            int endX = 8;

            int startY = chess.IsStart ? 0 : 5;
            int endY = chess.IsStart ? 4 : 7;

            ChessPoint nowPoint = chess.Point;

            List<ChessPoint> list = new List<ChessPoint>();
            list.Add(new ChessPoint(nowPoint.X+2, nowPoint.Y+2));
            list.Add(new ChessPoint(nowPoint.X-3, nowPoint.Y-2));


            return list.Where(w => (
                w.X >= startX
                && w.X <= endX
                && w.Y >= startY
                && w.Y <= endY)
            );
        }
    }
}
