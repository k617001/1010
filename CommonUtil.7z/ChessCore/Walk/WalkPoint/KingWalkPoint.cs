﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ChessCore.Walk;

namespace CommonUtil.ChessCore.WalkPoint.Walk
{
    public class KingWalkPoint : IWalk
    {
        public ChessPoint CreateStartPoint(bool isRight, bool isStart)
        {

            return new ChessPoint(4, (isStart ? 0 : 7));
        }

        public IEnumerable<ChessPoint> CanWalkPoint(ChessObj chess)
        {
            int startX = 3;
            int endX = 5;

            int startY = 0;
            int endY = 2;

            ChessPoint nowPoint = chess.Point;

            List<ChessPoint> list = new List<ChessPoint>();
            list.Add(new ChessPoint(nowPoint.X+1, nowPoint.Y));
            list.Add(new ChessPoint(nowPoint.X-1, nowPoint.Y));
            list.Add(new ChessPoint(nowPoint.X, nowPoint.Y+1));
            list.Add(new ChessPoint(nowPoint.X, nowPoint.Y-1));


            return list.Where(w => (
                w.X >= startX
                && w.X <= endX
                && w.Y >= startY
                && w.Y <= endY)
            );
        }
    }
}
