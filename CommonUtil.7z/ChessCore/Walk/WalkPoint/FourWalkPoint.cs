﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ChessCore.Walk;

namespace CommonUtil.ChessCore.WalkPoint.Walk
{
    public class FourWalkPoint : IWalk
    {
        public ChessPoint CreateStartPoint(bool isRight, bool isStart)
        {
            int x = isRight ? 3 : 5;
            int y = isStart ? 0 : 7;

            return new ChessPoint(x, y);
        }

        public IEnumerable<ChessPoint> CanWalkPoint(ChessObj chess)
        {
            int startX = 3;
            int endX = 5;

            int startY = 0;
            int endY = 2;

            ChessPoint nowPoint = chess.Point;

            List<ChessPoint> list = new List<ChessPoint>();
            list.Add(new ChessPoint(nowPoint.X+1, nowPoint.Y+1));
            list.Add(new ChessPoint(nowPoint.X-1, nowPoint.Y+1));
            list.Add(new ChessPoint(nowPoint.X+1, nowPoint.Y-1));
            list.Add(new ChessPoint(nowPoint.X-1, nowPoint.Y-1));


            return list.Where(w => (
                w.X >= startX
                && w.X <= endX
                && w.Y >= startY
                && w.Y <= endY)
            );
        }
    }
}
