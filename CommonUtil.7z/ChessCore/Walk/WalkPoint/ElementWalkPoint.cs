﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ChessCore.Walk;

namespace CommonUtil.ChessCore.WalkPoint.Walk
{
    public class CarWalkPoint : IWalk
    {
        public ChessPoint CreateStartPoint(bool isRight, bool isStart)
        {

            int x = isRight ? 0 : 7;
            int y = isStart ? 0 : 7;
            return new ChessPoint(x, y);
        }

        public IEnumerable<ChessPoint> CanWalkPoint(ChessObj chess)
        {
            int startX = 0;
            int endX = 8;

            int startY = chess.IsStart ? 0 : 7;
            int endY = chess.IsStart ? 0 : 7;

            ChessPoint nowPoint = chess.Point;

            List<ChessPoint> list = new List<ChessPoint>();
            for (int y = 1; y <= 7; y++ )
            {
                list.Add(new ChessPoint(nowPoint.X, nowPoint.Y + y));
                list.Add(new ChessPoint(nowPoint.X, nowPoint.Y - y));
            }
            for (int x = 1; x <= 8; x++)
            {
                list.Add(new ChessPoint(nowPoint.X + x, nowPoint.Y));
                list.Add(new ChessPoint(nowPoint.X - x, nowPoint.Y));
            }


            return list.Where(w => (
                w.X >= startX
                && w.X <= endX
                && w.Y >= startY
                && w.Y <= endY)
            );
        }
    }
}
