﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.ChessCore.Walk
{
    public class ChessPoint
    {
        public ChessPoint(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }

        public int X { set; get; }
        public int Y { set; get; }
    }
}
