﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.ChessCore.Walk
{
    public interface IWalk
    {
        IEnumerable<ChessPoint> CanWalkPoint(ChessObj chess);

        ChessPoint CreateStartPoint(bool isRight, bool isStart);
    }
}
