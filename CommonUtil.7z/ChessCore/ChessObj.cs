﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ChessCore.Walk;

namespace CommonUtil.ChessCore
{
    public class ChessObj
    {
        private IWalk walkObj = null;
        public ChessObj(
            ChessEnums Type, 
            string text,
            ChessColorEnums color,
            bool isStart,
            bool isRight)
        {
            walkObj = WalkFactory.GetWalkInstance(Type);

            this.Type = Type;
            this.Text = text;
            this.Color = color;
            this.Point = walkObj.CreateStartPoint(isStart, isRight);
            this.IsStart = isStart;
        }

        public ChessEnums Type { set; get; }

        public string Text { set; get; }

        public ChessColorEnums Color { set; get; }

        public ChessPoint Point { set; get; }

        public bool IsStart { set; get; }

        public IEnumerable<ChessPoint> CanWalkPoints()
        {
            IEnumerable<ChessPoint> points = walkObj.CanWalkPoint(this);

            Console.WriteLine("CanWalkPoints()");
            foreach(ChessPoint p in points) 
            {
                Console.WriteLine("x => " + p.X + ", y => " + p.Y);
            }

            return points;
        }

        public void SetPoint(int x, int y)
        {
            Console.WriteLine("=====");
            this.Point.X = x;
            this.Point.Y = y;
        }

        public void PrintPoint()
        {
            Console.WriteLine("x => " + this.Point.X + ", y => " + this.Point.Y);
        }
    }
}
