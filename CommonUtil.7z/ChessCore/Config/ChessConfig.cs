﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.ChessCore.Config
{
    public class ChessConfig
    {
        public static int MAP_MAX_X = 9;
        public static int MAP_MAX_Y = 9;

        public static int MAP_HELF = 4;
    }
}
