﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ChessCore.Walk;

namespace CommonUtil.ChessCore
{
    public class ChreeCoreAction
    {
        public void Action()
        {
            WalkFactory.Register();

            //KingTest();
            FourTest();
        }

        private void FourTest()
        {

            ChessObj four = new ChessObj(ChessEnums.FOUR, "士", ChessColorEnums.BLOCK, true, true);

            four.PrintPoint();
            four.CanWalkPoints();

            four.SetPoint(4, 1);
            four.PrintPoint();
            four.CanWalkPoints();

            four.SetPoint(5, 2);
            four.PrintPoint();
            four.CanWalkPoints();
        }

        private void KingTest()
        {

            ChessObj king = new ChessObj(ChessEnums.KING, "將", ChessColorEnums.BLOCK, true, true);

            king.PrintPoint();
            king.CanWalkPoints();

            king.SetPoint(4, 1);

            king.PrintPoint();
            king.CanWalkPoints();

            king.SetPoint(4, 2);

            king.PrintPoint();
            king.CanWalkPoints();

            king.SetPoint(3, 2);

            king.PrintPoint();
            king.CanWalkPoints();
        }
    }
}
