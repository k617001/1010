﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Case1.ValueObject;
using CommonUtil.Case1.Run;
using CommonUtil.Case1.Config;

namespace CommonUtil.Case1.Anslysis
{
    /// <summary>
    /// 以背包問題解的分析
    /// </summary>
    public class KnapsackProblemMain : BaseMain
    {

        /// <summary>
        /// 分析
        /// </summary>
        public override void DataAnalysis() 
        {
            BoardVO[] boardDataTmp = DataAcess.CopyBoardData();

            int nullCount = 0;
            while (boardDataTmp.Length > 0)
            {
                ResultVO vo = PackResult(boardDataTmp);
                if (vo == null)
                {
                    if (++nullCount >= 3)
                    {
                        throw new Exception("無資料大於三次以上!!");
                    }

                    continue;
                }

                base.resultList.Add(vo);

                //取差集，把原有的資料刪掉
                boardDataTmp = boardDataTmp.Except(vo.BoardVOs).ToArray();

            }
        }

        private ResultVO PackResult(BoardVO[] boardDataTmp)
        {
            List<ResultVO> boxResultList = new List<ResultVO>();
            //以盒子為主
            foreach (BoardBoxVO boxVO in DataAcess.boxData)
            {
                boxVO.SetStandardWH(boxVO.Width);

                //依可塞進盒子的board做分類及排序，增加準確性
                List<BoardVO> boards = getCheckBoard(boxVO, boardDataTmp);


                if (boards.Count == 0)
                {
                    continue;
                }

                ResultVO boxResultVO = new ResultVO()
                {
                    BoxVO = boxVO,
                };

                //放進背包裡
                IntoPack(boxResultVO, boards);

                boxResultList.Add(boxResultVO);
            }

            double minArea = boxResultList.Min(m => m.BoxLeftArea);
            return boxResultList.Where(w => w.BoxLeftArea == minArea).FirstOrDefault();
        }

        /// <summary>
        /// 單個背包裝的容量最小值
        /// </summary>
        /// <param name="boxVO"></param>
        /// <param name="boards"></param>
        private void IntoPack(ResultVO boxResultVO, List<BoardVO> boards)
        {
            BoardBoxVO box = boxResultVO.BoxVO;

            List<BoardVO> sortBoards = boards.OrderBy(o => o.StandardWidth).ToList();


            foreach (BoardVO boardVO in boards)
            {
                //面積超過時不記錄
                double areaSize = boardVO.Area + boxResultVO.BoardArea;
                if (areaSize > box.Area)
                {
                    continue;
                }

                //寬度超過不記錄
                double width = boardVO.StandardWidth > boxResultVO.BoardWidth ? boardVO.StandardWidth : boxResultVO.BoardWidth;
                if (width > box.StandardWidth)
                {
                    continue;
                }

                //長度超過不記錄
                double height = boardVO.StandardHeight + boxResultVO.BoardHeight;
                if (height > box.StandardHeight)
                {
                    continue;
                }

                boxResultVO.AddBoardVO(boardVO);
            }
        }


        /// <summary>
        /// 取得可塞進盒子的board
        /// </summary>
        /// <param name="boxVO"></param>
        /// <returns></returns>
        public List<BoardVO> getCheckBoard(BoardBoxVO boxVO, BoardVO[] boardDataTmp)
        {
            foreach (BoardVO vo in boardDataTmp)
            {
                vo.SetStandardWH(boxVO.Width);
            }

            List<BoardVO> rtnBoardVO = boardDataTmp
                                    .Where(w => (
                                        boxVO.StandardWidth >= w.StandardWidth
                                        && boxVO.StandardHeight >= w.StandardHeight
                                        && boxVO.StandardWidth - (boxVO.StandardWidth * ConfigInfo.FILTER_PERCENT / 100) <= w.StandardWidth
                                        && boxVO.StandardHeight - (boxVO.StandardHeight * ConfigInfo.FILTER_PERCENT / 100) * ConfigInfo.FILTER_PERCENT <= w.StandardHeight
                                        ))
                                        .OrderByDescending(o => o.StandardWidth)
                                        .ToList();

            return rtnBoardVO;
        }
    }
}
