﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Case1.ValueObject;

namespace CommonUtil.Case1.Output
{
    public class OutputResult
    {
        /// <summary>
        /// 顯示結果
        /// </summary>
        /// <param name="results"></param>
        public static void Output(List<ResultVO> results)
        {
            StringBuilder output = new StringBuilder();
            foreach(ResultVO resultVO in results) 
            {
                output.Append(resultVO.BoxVO.Info() + "\n");
                foreach (BoardVO boardVo in resultVO.BoardVOs)
                {
                    output.Append("\t-" + boardVo.Info() + "\n");
                }

                output.Append("\n\n");
            }

            Console.WriteLine(output);
        }
    }
}
