﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Case1.Config
{
    public class ConfigInfo
    {
        /// <summary>
        /// 分類的百分比
        /// </summary>
        public readonly static int FILTER_PERCENT = 100;
    }
}
