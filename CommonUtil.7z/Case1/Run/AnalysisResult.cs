﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Case1.ValueObject;
using CommonUtil.Case1.Anslysis;

namespace CommonUtil.Case1.Run.Data
{
    public class AnalysisResult
    {
        /// <summary>
        /// 以box為主
        /// </summary>
        /// <returns></returns>
        public static List<ResultVO> GetForMainBox()
        {
            return new KnapsackProblemMain().Result();
        }


        /// <summary>
        /// 以board為主
        /// </summary>
        /// <returns></returns>
        public static List<ResultVO> GetForMainBoard()
        {
            return null;
        }
    }
}
