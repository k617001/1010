﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Case1.ValueObject
{
    public class CombinBoardVO : BoardVO
    {
        List<BoardVO> boardVOs = new List<BoardVO>();

        public void AddBoardVO(BoardVO boardVO)
        {
            boardVOs.Add(boardVO);

            foreach (BoardVO vo in boardVOs)
            {
            }
        }
    }
}
