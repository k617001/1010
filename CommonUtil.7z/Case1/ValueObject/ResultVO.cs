﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Case1.ValueObject
{
    public class ResultVO
    {
        
        public ResultVO()
        {
            BoardVOs = new List<BoardVO>();
        }

        public List<BoardVO> BoardVOs { set; get; }

        public BoardBoxVO BoxVO { set; get; }

        /// <summary>
        /// 所有板子的面積
        /// </summary>
        public double BoardArea { set; get; }

        /// <summary>
        /// 所有板子最大的長
        /// </summary>
        public double BoardHeight { set; get; }

        /// <summary>
        /// 所有板子最大的寬
        /// </summary>
        public double BoardWidth { set; get; }

        /// <summary>
        /// 剩下Box的面積
        /// </summary>
        public double BoxLeftArea { set; get; }

        /// <summary>
        /// 記錄板子及統計
        /// </summary>
        /// <param name="vo"></param>
        public void AddBoardVO(BoardVO vo)
        {
            BoardVOs.Add(vo);

            foreach (BoardVO bVO in BoardVOs)
            {
                if (bVO.StandardHeight > BoardHeight)
                {
                    this.BoardHeight = bVO.StandardHeight;
                }

                if (bVO.StandardWidth > BoardWidth)
                {
                    this.BoardWidth = bVO.StandardWidth;
                }
            }
            this.BoardArea += vo.Area;

            BoxLeftArea = BoxVO.Area - this.BoardArea;
        }
    }
}
