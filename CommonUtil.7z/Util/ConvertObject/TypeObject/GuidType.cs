﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Util.ConvertObject.TypeObject
{

    public class GuidType : ITypeObject<Guid>
    {

        public Guid ConvertValue(object value)
        {
            return ConvertValue(value, Guid.Empty);
        }

        public Guid ConvertValue(object value, Guid defaultValue)
        {
            if (value == null)
            {
                return defaultValue;
            }

            Guid rtnValue = Guid.Empty;
            Guid.TryParse(value.ToString(), out rtnValue);
            return rtnValue;
        }
    }
}
