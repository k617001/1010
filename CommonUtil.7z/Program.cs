﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ObjectContainer;
using CommonUtil.Case1;
using CommonUtil.Helper.Entity;
using System.Reflection;
using CommonUtil.Util;
using CommonUtil.Util.ConvertObject;
using CommonUtil.ChessCore;
using System.Runtime.Remoting;
using CommonUtil.Helper.CSVLoad.Plus;

namespace CommonUtil
{
    class Program
    {
        static void Main(string[] args)
        {
            //new ChreeCoreAction().Action();

            //GetColumns(typeof(TestTable));

            /*
            string v = "2017/2/16";

            string[] dateSp = v.Split('/');

            string dateStr = dateSp[0] + "/" + dateSp[1].PadLeft(2, '0') + "/" + dateSp[2].PadLeft(2, '0');

            DateTime dt = DateTime.ParseExact(dateStr, "yyyy/MM/dd", System.Globalization.CultureInfo.InvariantCulture);
             * */
            //CsvConnection csvConn = new CsvConnection(@"D:\marketData");

            new CsvConnTest().Action();

        }

        public class TestClass
        {
            public int A { set; get; }

            public string B { set; get; }

        }
        

        private static string[] GetColumns(Type objType)
        {
            return
                objType
                    .GetProperties()
                    .Select(s => s.Name)
                    .ToArray();
        }
    }


}
