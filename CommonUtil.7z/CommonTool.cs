﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CommonUtil
{
    public class CommonTool
    {
        public static void StringToFile(string path, string content)
        {
            string filename = Path.GetFileName(path);

            string fileDirPath = path.Replace(filename, "");

            StringToFile(fileDirPath, filename, content);
        }
        public static void StringToFile(string path, string fileName, string content)
        {
            Directory.CreateDirectory(path);
            using (StreamWriter sw = new StreamWriter(path + fileName))
            {
                sw.Write(content);
            }
        }

        public static Dictionary<T2, List<T1>> ToDictionaryList<T1, T2>(List<T1> values, Func<T1, T2> keyFun)
        {
            Dictionary<T2, List<T1>> map = new Dictionary<T2, List<T1>>();

            foreach(T1 value in values) 
            {
                T2 key = keyFun(value);

                if (!map.ContainsKey(key))
                {
                    map.Add(key, new List<T1>());
                }
                map[key].Add(value);
            }
            return map;
        }
    }
}
