﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CommonUtil.Helper.ExcelHelper;
using NPOI.SS.UserModel;
using System.Data;
using System.Text;

namespace CommonUtil.Helper.ExcelHelper
{
    /// <summary>
    /// 驗証excel使用
    /// </summary>
    public class ExcelVaildHelper
    {
        ExcelReaderHelper readerHelper = null;
        int cellSize = 0;

        //空值row記錄
        List<string> errorRow_Null = new List<string>();

        //重覆資料記錄
        HashSet<string> noExistList = new HashSet<string>();
        HashSet<string> existList = new HashSet<string>();

        //自訂的錯誤訊息
        Dictionary<string, StringBuilder> customMsg = new Dictionary<string, StringBuilder>();

        public ExcelVaildHelper(ExcelReaderHelper readerHelper)
        {
            this.readerHelper = readerHelper;
        }

        /// <summary>
        /// 判斷整個row有沒有空值，有空值則記錄錯誤log，不會自動換下個row
        /// 全空值則不記錄log
        /// </summary>
        /// <returns></returns>
        public bool IsRowHasNull(int cellSize)
        {
            //目前cell座標
            int nowCellIdx = readerHelper.GetCellIndex();
            bool isRowHasNull = false;
            int nullSum = 0;
            for (int cellIdx = 0; cellIdx < cellSize; cellIdx++ )
            {
                readerHelper.SetCellIndex(cellIdx);
                ICell cell = readerHelper.GetCell();
                cell.SetCellType(CellType.String);
                string value = cell.StringCellValue;

                if (cell == null || string.IsNullOrEmpty(value))
                {
                    nullSum++;
                }
            }

            //有一個cell沒有值則記錄該row的index
            if (nullSum > 0 && nullSum < cellSize)
            {
                errorRow_Null.Add(readerHelper.GetRowIndex() + 1 + "");//記錄空值的row
                isRowHasNull = true;
            }

            //全空值不記錄
            if (nullSum > 0 && nullSum == cellSize)
            {
                isRowHasNull = true;
            }

            readerHelper.SetCellIndex(nowCellIdx);
            return isRowHasNull;
        }

        /// <summary>
        /// 取得有空值的row的清單
        /// </summary>
        public List<string> GetNullRowList()
        {
            return this.errorRow_Null;
        }

        /// <summary>
        /// 設定是否重覆
        /// </summary>
        /// <returns></returns>
        public bool Exist(string data)
        {
            if (this.noExistList.Contains(data))
            {
                this.existList.Add(data);
                return true;
            }
            this.noExistList.Add(data);

            return false;
        }

        /// <summary>
        /// 取得重覆的清單
        /// </summary>
        public IEnumerable<string> GetExistList()
        {
            return this.existList;
        }

        /// <summary>
        /// 設定自訂的錯誤訊息
        /// </summary>
        public void AddCustomMsg(string key, string message)
        {
            if (!this.customMsg.ContainsKey(key))
            {
                this.customMsg.Add(key, new StringBuilder());
            }
            this.customMsg[key].AppendLine(message);
        }

        /// <summary>
        /// 設定自訂的錯誤訊息
        /// </summary>
        public string GetCustomMsg(string key)
        {
            if (!this.customMsg.ContainsKey(key))
            {
                return "";
            }
            return this.customMsg[key].ToString();
        }
    }
}