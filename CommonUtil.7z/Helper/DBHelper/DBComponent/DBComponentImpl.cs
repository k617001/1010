﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using CommonUtil.Util;

namespace CommonUtil.Helper.DBHelper.DBComponent
{
    public class DBComponentImpl : IDBComponent
    {
        string connectionStr = null;
        public DBComponentImpl(string connectionStr) {
            this.connectionStr = connectionStr;
        }

        public int Insert<T>(T entity)
        {
            throw new NotImplementedException();
        }

        public int Update<T>(T entity)
        {
            throw new NotImplementedException();
        }

        public int Delete<T>(T entity)
        {
            throw new NotImplementedException();
        }

        public void Execute(string sql, Dictionary<string, object> param)
        {
            throw new NotImplementedException();
        }

        public int Commit()
        {
            throw new NotImplementedException();
        }

        public List<T> FindList<T>(string sql, Dictionary<string, object> param)
        {
            throw new NotImplementedException();
        }

        public List<T> FindList<T>(string sql)
        {
            return FindList<T>(sql, null);
        }

        public T FindByPK<T>(string sql, Dictionary<string, object> param)
        {
            Type objType = typeof(T);
            return FindObject<T>(sql, param, r =>
            {
                if (r.Read())
                {
                    T obj = (T)Activator.CreateInstance(objType);
                    for (int i = 0; i < r.FieldCount; i++)
                    {
                        PropertyInfo property = objType.GetProperty(r.GetName(i));
                        if (property == null)
                        {
                            continue;
                        }
                        object value = r.GetValue(i);
                        if (value.Equals(DBNull.Value))
                        {
                            continue;
                        }

                        property.SetValue(obj, value, null);
                    }
                    return obj;
                }

                return default(T);
            });
        }

        public T FindByPK<T>(string sql)
        {
            throw new NotImplementedException();
        }

        private T FindObject<T>(string sql, Dictionary<string, object> param, Func<IDataReader, T> func) 
        {
            using (SqlConnection conn = new SqlConnection(this.connectionStr)) 
            {
                using (SqlCommand comm = new SqlCommand(sql, conn)) 
                {
                    //設定參數
                    SetParam(comm, param);

                    if (conn.State != ConnectionState.Open) 
                    {
                        conn.Open();
                    }

                    using (IDataReader reader = comm.ExecuteReader())
                    {
                        return func(reader);
                    }
                }
            }
        }

        private void SetParam(SqlCommand comm, Dictionary<string, object> param) 
        {
            if(param == null || param.Count == 0) 
            {
                return;
            }

            foreach(string key in param.Keys) 
            {
                comm.Parameters.Add(new SqlParameter(key, param[key]));
            }
        }
    }
}
