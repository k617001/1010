﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using CommonUtil.Util.ConvertObject;

namespace Trading.Src.Common.Helper.DB
{
    public class DBHelper
    {
        string connStr = string.Empty;
        public DBHelper(string connStr)
        {
            this.connStr = connStr;
        }


        /// <summary>
        /// 查詢清單
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="strsql"></param>
        /// <param name="paramsMap"></param>
        /// <returns></returns>
        public bool IsConnection()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    return true;
                }
            }
            catch(Exception) {
                return false;
            }
        }

        /// <summary>
        /// execute資料，無參數
        /// </summary>
        /// <param name="exSQL"></param>
        /// <param name="param"></param>
        public int Execute(string exSQL)
        {
            return this.Execute(exSQL, null);
        }

        /// <summary>
        /// execute資料
        /// </summary>
        /// <param name="exSQL"></param>
        /// <param name="param"></param>
        public int Execute(string exSQL, Dictionary<string, object> param)
        {
            int count = 0;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();
                using (SqlCommand cmd = new SqlCommand(exSQL, conn))
                {
                    ///設定參數值
                    SetParameters(cmd, param);
                    cmd.Transaction = trans;
                    cmd.ExecuteNonQuery();
                }
                trans.Commit();
            }

            return count;
        }

        /// <summary>
        /// execute資料，只做DataTable的第一筆
        /// </summary>
        /// <param name="exSQL"></param>
        /// <param name="param"></param>
        public int ExecuteDataTable(string exSQL, DataTable param)
        {
            int count = 0;
            if (param.Rows.Count == 0)
            {
                return count;
            }
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();
                using (SqlCommand cmd = new SqlCommand(exSQL, conn))
                {
                    cmd.Transaction = trans;

                    DataRow dr = param.Rows[0];//只取第一筆
                    foreach (DataColumn c in dr.Table.Columns)
                    {
                        string name = c.ColumnName;
                        cmd.Parameters.AddWithValue("@" + name, dr[name]);
                    }
                    cmd.ExecuteNonQuery();
                }
                trans.Commit();
            }
            return count;
        }

        /// <summary>
        /// 查詢，無參數
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns></returns>
        public DataTable FindBySQL(string qrySQL)
        {
            return this.FindBySQL(qrySQL, null);
        }


        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns></returns>
        public PageDataVO FindPageBySQL(string qrySQL, string qryCountSQL, Dictionary<string, object> param, int currentPage)
        {
            return FindPageBySQL(qrySQL, qryCountSQL, param, currentPage, 10);
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns></returns>
        public PageDataVO FindPageBySQL(string qrySQL, string qryCountSQL, Dictionary<string, object> param, int currentPage, int pageSize)
        {
            string qryPageSQL = @"
SELECT TOP(" + pageSize + @") * 
FROM 
(
" + qrySQL + @"
) AS T
WHERE RowNo > ((" + currentPage + @" - 1) * " + pageSize + @") 
";

            int dataCount = 0;
            DataTable result = new DataTable();
            using (SqlConnection connection = new SqlConnection(connStr))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(qryCountSQL, connection))
                {
                    SetParameters(cmd, param);
                    dataCount = (int)cmd.ExecuteScalar();
                }

                using (SqlCommand cmd = new SqlCommand(qryPageSQL, connection))
                {
                    SetParameters(cmd, param);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(result);
                    }
                }
            }

            PageDataVO vo = new PageDataVO()
            {
                Data = result,
                Currentpage = currentPage,
                DataCount = dataCount,
                PageSize = pageSize,
                PageCount = dataCount / pageSize + 1

            };
            return vo;
        }


        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns></returns>
        public DataTable FindBySQL(string qrySQL, Dictionary<string, object> param)
        {
            DataTable result = new DataTable();
            using (SqlConnection connection = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(qrySQL, connection))
                {
                    SetParameters(cmd, param);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(result);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// 查詢,只回傳第一筆資料，組sql最好加top 1
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns>無資料回傳null</returns>
        public DataRow FindSingleBySQL(string qrySQL, Dictionary<string, object> param)
        {
            DataTable table = this.FindBySQL(qrySQL, param);

            if (table.Rows.Count == 0)
            {
                return null;
            }

            return table.Rows[0];
        }

        /// <summary>
        /// 查詢,只回傳第一筆資料，組sql最好加top 1
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns>無資料回傳null</returns>
        public DataRow FindSingleBySQL(string qrySQL)
        {
            return this.FindSingleBySQL(qrySQL, null);
        }

        /// <summary>
        /// 查詢,只回傳第一筆資料第一個欄位的值，
        /// 組sql最好加top 1且給一個欄位
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns>無資料時回傳預設值</returns>
        public T FindValueBySQL<T>(string qrySQL, Dictionary<string, object> param)
        {
            DataRow dataRow = this.FindSingleBySQL(qrySQL, param);

            if (dataRow == null)
            {
                return ConvertObject.To<T>(null);
            }

            return ConvertObject.To<T>(dataRow[0]);
        }

        /// <summary>
        /// 查詢,只回傳第一筆資料第一個欄位的值，
        /// 組sql最好加top 1且給一個欄位
        /// </summary>
        /// <param name="qrySQL"></param>
        /// <returns>無資料時回傳預設值</returns>
        public T FindValueBySQL<T>(string qrySQL)
        {
            return FindValueBySQL<T>(qrySQL, null);
        }

        /// <summary>
        /// 設定參數
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="param"></param>
        private void SetParameters(SqlCommand cmd, Dictionary<string, object> param)
        {
            if (param == null || param.Count == 0)
            {
                return;
            }

            foreach (string key in param.Keys)
            {
                cmd.Parameters.Add(key, param[key]);
            }
        }
    }
} 