﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CommonUtil.Helper.DBHelper
{
    public class BatchHelper
    {
        List<BatchSet> setList = new List<BatchSet>();

        string connectionStr = null;
        public BatchHelper(string connectionStr)
        {
            this.connectionStr = connectionStr;
        }

        /// <summary>
        /// 記錄batchInsert
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="data"></param>
        public void BatchInsert(string tableName, DataTable data)
        {
            BatchSet set = new BatchSet();
            set.Type = BatchCommandEnum.BatchInsert;
            set.Table = tableName;
            set.Data = data;

            setList.Add(set);
        }

        /// <summary>
        /// 記錄sql執行
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="data"></param>
        public void ExecuteSQL(string sql, DataTable data)
        {
            BatchSet set = new BatchSet();
            set.Type = BatchCommandEnum.SQLExecute;
            set.SQL = sql;
            set.Data = data;

            setList.Add(set);
        }

        /// <summary>
        /// 主要執行程式
        /// </summary>
        public void Commit()
        {
            using (SqlConnection conn = new SqlConnection(connectionStr))
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();

                foreach(BatchSet setObj in setList) {
                    if (BatchCommandEnum.BatchInsert == setObj.Type)
                    {
                        SqlBulkCopyBatchInsert(conn, trans, setObj);
                    }
                    else if (BatchCommandEnum.SQLExecute == setObj.Type)
                    {
                        BatchExecuteSQL(conn, trans, setObj);
                    }
                }

                trans.Commit();
            }
        }

        private void SqlBulkCopyBatchInsert(SqlConnection conn, SqlTransaction trans, BatchSet batchSet)
        {

            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, trans))
            {
                bulkCopy.DestinationTableName = batchSet.Table;
                bulkCopy.WriteToServer(batchSet.Data);
            }
        }

        private void BatchExecuteSQL(SqlConnection conn, SqlTransaction trans, BatchSet batchSet)
        {

            if (batchSet.Data == null || batchSet.Data.Rows.Count == 0)
            {
                using (SqlCommand cmd = new SqlCommand(batchSet.SQL, conn))
                {
                    cmd.Transaction = trans;
                    cmd.ExecuteNonQuery();
                }
                return;
            }

            foreach (DataRow dr in batchSet.Data.Rows)
            {
                using (SqlCommand cmd = new SqlCommand(batchSet.SQL, conn))
                {
                    cmd.Transaction = trans;
                    foreach (DataColumn c in dr.Table.Columns)
                    {
                        string name = c.ColumnName;
                        cmd.Parameters.AddWithValue("@" + name, dr[name]);
                    }
                    cmd.ExecuteNonQuery();
                }
            }
        }


        public class BatchSet
        {
            public BatchCommandEnum Type { set; get; }

            public DataTable Data { set; get; }

            public string Table { set; get; }

            public string SQL { set; get; }
        }

        public enum BatchCommandEnum
        {
            BatchInsert,
            SQLExecute,
        }
    }
}
