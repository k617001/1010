﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace Trading.Src.Common.Helper.DB
{
    public class PageDataVO
    {
        /// <summary>
        /// 資料
        /// </summary>
        public DataTable Data { set; get; }
        /// <summary>
        /// 目前使用頁面
        /// </summary>
        public int Currentpage { set; get; }
        /// <summary>
        /// 一頁幾筆資料
        /// </summary>
        public int PageSize { set; get; }
        /// <summary>
        /// 資料筆數
        /// </summary>
        public int DataCount { set; get; }
        /// <summary>
        /// 分頁數
        /// </summary>
        public int PageCount { set; get; }
    }
}