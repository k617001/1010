﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Helper.CSVLoad.Plus
{
    public class CsvConnTest
    {
        public void Action()
        {

            string path = @"D:\marketData";
            CsvConnection csvConn = new CsvConnection(path);

            csvConn.SetRunFileName("data.csv");
            csvConn.Query(
                (row, convert) =>
                {
                    string date = convert.Get<string>("date");
                    Console.WriteLine(date);
                }
            );
        }
    }
}
