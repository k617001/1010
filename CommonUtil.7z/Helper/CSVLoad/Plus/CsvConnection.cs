﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace CommonUtil.Helper.CSVLoad.Plus
{
    /// <summary>
    /// csv當資料庫玩
    /// 整個資料夾當資料庫，裡面的檔案當tableName
    /// </summary>
    public class CsvConnection
    {
        string EX_NAME = "csv";
        string path = null;
        Dictionary<string, string> csvNameMap = null;

        string runFileName = null;
        string[] otherExName = new string[0];

        public CsvConnection(string path)
        {
            this.path = FixPath(path);
            Init();
        }


        public CsvConnection(string path, string[] otherExName)
        {
            this.path = FixPath(path);
            this.otherExName = otherExName;
            Init();
        }

        private string FixPath(string path)
        {
            string lastStr = path.Substring(path.Length - 1, path.Length - (path.Length - 1));
            if (@"\".Equals(lastStr) || @"/".Equals(lastStr))
            {
                return path;
            }

            return path + @"\";
        }

        private void Init()
        {
            if (otherExName.Length == 0)
            {
                otherExName = new string[] {
                    EX_NAME
                };
            }

            //取得檔名
            string pattern = string.Join("|", otherExName.Select(s => "." + s.Replace(".", ""))) + "|" + EX_NAME;

            this.csvNameMap = Directory.GetFiles(path).Where(w =>
            {
                return Regex.IsMatch(w, pattern);
            })
            .ToDictionary(k => Path.GetFileName(k));

        }

        public string[] GetFileNames()
        {
            return this.csvNameMap.Keys.OrderBy(o => o).ToArray();
        }

        /// <summary>
        /// 是否存在
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public bool IsExist(string fileName)
        {
            return !csvNameMap.ContainsKey(fileName);
        }

        public CsvConnection SetRunFileName(string fileName)
        {

            if (!csvNameMap.ContainsKey(fileName))
            {
                File.Create(path + fileName);
                Init();
            }
            this.runFileName = fileName;
            return this;
        }

        public void Query(Action<int, CSVLoadConvert> loadAction)
        {
            if (string.IsNullOrEmpty(this.runFileName))
            {
                throw new Exception("未設定目前要執行的檔案!!! 設定method=> SetRunFileName()");
            }

            if (loadAction == null)
            {
                throw new Exception("未設定目前要執行的方法!!!");
            }

            CSVLoadHelper.LoadCsv(csvNameMap[this.runFileName], loadAction);
        }

        /// <summary>
        /// 建檔
        /// </summary>
        public bool CreateFile()
        {
            if (string.IsNullOrEmpty(this.runFileName))
            {
                throw new Exception("未設定目前要執行的檔案!!! 設定method=> SetRunFileName()");
            }
            string path = csvNameMap[this.runFileName];
            if (!File.Exists(path))
            {
                File.Create(path);
                return true;
            }
            return false;
        }

        public void DeleteAll()
        {
            string path1 = csvNameMap[this.runFileName];
            File.Delete(path1);

            File.Create(path1);
        }

        /// <summary>
        /// 寫入
        /// </summary>
        /// <param name="content"></param>
        public void Insert(string title, string content)
        {
            string path1 = csvNameMap[this.runFileName];
            FileInfo fInfo = new FileInfo(path1);
            if (CreateFile() || fInfo.Length == 0)
            {
                content = title + "\r\n" + content;
            }

            using (StreamWriter w = File.AppendText(path1))
            {
                w.Write(content);
            }
        }

        /// <summary>
        /// 寫檔
        /// </summary>
        /// <param name="content"></param>
        public void Save(string title, string content)
        {
            string path1 = csvNameMap[this.runFileName];
            CommonTool.StringToFile(path1, title + "\r\n" + content);
        }
    }
}
