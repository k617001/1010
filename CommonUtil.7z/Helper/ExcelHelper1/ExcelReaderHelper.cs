﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.UserModel;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;

namespace CommonUtil.Helper.ExcelHelper
{
    public class ExcelReaderHelper : BaseExcel
    {
        /// <summary>
        /// 取得cell值-字串，自動換下一個cell
        /// </summary>
        /// <returns></returns>
        public string GetCellValueString()
        {
            string value = GetStringValue();
            this.cellIndex++;
            return value;
        }


        /// <summary>
        /// 取得cell值-日期，自動換下一個cell
        /// </summary>
        /// <returns></returns>
        public DateTime GetCellValueDateTime()
        {
            DateTime value = this.GetDateTimeValue();
            this.cellIndex++;
            return value;
        }


        /// <summary>
        /// 取得cell值-數值，自動換下一個cell
        /// </summary>
        /// <returns></returns>
        public double GetCellValueNumeric()
        {
            double value = GetNumericValue();
            this.cellIndex++;
            return value;
        }

        /// <summary>
        /// 取得row值-字串，自動換下一個row
        /// </summary>
        /// <returns></returns>
        public string GetRowValueString()
        {
            string value = GetStringValue();
            this.rowIndex++;
            return value;
        }


        /// <summary>
        /// 取得row值-日期，自動換下一個row
        /// </summary>
        /// <returns></returns>
        public DateTime GetRowValueDateTime()
        {
            DateTime value = this.GetDateTimeValue();
            this.rowIndex++;
            return value;
        }


        /// <summary>
        /// 取得row值-數值，自動換下一個row
        /// </summary>
        /// <returns></returns>
        public double GetRowValueNumeric()
        {
            double value = GetNumericValue();
            this.rowIndex++;
            return value;
        }

        /// <summary>
        /// 取得字串值
        /// </summary>
        /// <returns></returns>
        private string GetStringValue()
        {
            ICell cell = GetCell();

            if (cell == null)
            {
                return null;
            }

            cell.SetCellType(CellType.String);

            string value = cell.StringCellValue;
            return value;
        }

        /// <summary>
        /// 取得數字值
        /// </summary>
        /// <returns></returns>
        private double GetNumericValue()
        {
            ICell cell = GetCell();

            if (cell == null)
            {
                return 0;
            }

            double value = cell.NumericCellValue;
            return value;
        }

        /// <summary>
        /// 取得日期值
        /// </summary>
        /// <returns></returns>
        private DateTime GetDateTimeValue()
        {
            ICell cell = GetCell();

            if (cell == null)
            {
                return DateTime.MinValue;
            }

            DateTime value = cell.DateCellValue;
            return value;
        }

    }
}
