﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Helper.Entity
{
    public class TestTable
    {
        public string Zzzz { set; get; }

        public string Yyyy { set; get; }


    }
}
