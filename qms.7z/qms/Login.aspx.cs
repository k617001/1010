﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace qms
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string userName = "00001";
            Response.Cookies["emp_no"].Value = userName;
            Response.Cookies["emp_no"].Expires = DateTime.Now.AddMonths(1);



            FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(
              1,
              userName,
              DateTime.Now,
              DateTime.Now.AddMinutes(30),
              false,
              userName,
              FormsAuthentication.FormsCookiePath);

            // Encrypt the ticket.
            string encTicket = FormsAuthentication.Encrypt(ticket);

            HttpCookie myHttpCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);

            myHttpCookie.Secure = true;
            Response.Cookies.Add(myHttpCookie);

            Response.Redirect(FormsAuthentication.GetRedirectUrl(userName, false));
        }
    }
}