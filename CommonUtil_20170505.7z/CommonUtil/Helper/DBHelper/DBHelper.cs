﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace CommonUtil.Helper.DBHelper
{
    public class DBHelper
    {
        string connStr = string.Empty;
        public DBHelper(string connStr)
        {
            this.connStr = connStr;
        }

        /// <summary>
        /// 查詢清單
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="strsql"></param>
        /// <param name="paramsMap"></param>
        /// <returns></returns>
        public List<T> FindList<T>(string strsql, Dictionary<string, object> paramsMap)
        {
            List<T> rtnList = new List<T>();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = strsql;
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;

                    if (paramsMap != null && paramsMap.Count > 0)
                    {
                        foreach (string key in paramsMap.Keys)
                        {
                            object val = paramsMap[key];

                            if (val is IEnumerable<object>)
                            {
                            }
                            cmd.Parameters.AddWithValue(key, val);
                        }
                    }
                }

               


            }

            return rtnList;
        }

        private string[] GetColumns(Type objType)
        {
            return
                objType
                    .GetProperties()
                    .Select(s => s.Name)
                    .ToArray();
        }
    }
}
