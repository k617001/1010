﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ObjectContainer;
using CommonUtil.Case1;
using CommonUtil.Helper.Entity;
using System.Reflection;
using CommonUtil.Util;

namespace CommonUtil
{
    class Program
    {
        static void Main(string[] args)
        {
            new CaseRun().Action();
            
            //GetColumns(typeof(TestTable));
        }

        

        private static string[] GetColumns(Type objType)
        {
            return
                objType
                    .GetProperties()
                    .Select(s => s.Name)
                    .ToArray();
        }
    }
}
