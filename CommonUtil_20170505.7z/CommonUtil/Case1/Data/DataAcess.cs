﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Case1.ValueObject;

namespace CommonUtil.Case1.Run
{
    public class DataAcess
    {
        public static void SetData() 
        {
            //設定盒子的資料
            DataAcess.SetBoxData();
            //設定板子的資料
            DataAcess.SetBoardData();
        }

        public static BoardBoxVO[] boxData;

        public static void SetBoxData() 
        {
            string[] datas = new string[] 
            {
                "100*100",
                "200*100",
                "110*100",
                "90*100",
            };

            boxData = new BoardBoxVO[datas.Length];
            int idx = 0;
            foreach(string data in datas) 
            {
                string[] dd = data.Split('*');
                boxData[idx] = new BoardBoxVO("Box000" + idx, Convert.ToDouble(dd[0]), Convert.ToDouble(dd[1]));
                idx++;

            }
        }


        public static BoardVO[] boardData;

        public static void SetBoardData()
        {
            string[] datas = new string[] 
            {
                "50*100",
                "50*50",
                "50*50",
                "40*50",
                "50*50",
                "50*50",
            };

            boardData = new BoardVO[datas.Length];
            int idx = 0;
            foreach (string data in datas)
            {
                string[] dd = data.Split('*');
                boardData[idx] = new BoardVO("000" + idx, Convert.ToDouble(dd[0]), Convert.ToDouble(dd[1]));
                idx++;

            }

        }

        /// <summary>
        /// 複製BoardData
        /// </summary>
        /// <returns></returns>
        public static BoardVO[] CopyBoardData()
        {
            return (BoardVO[])boardData.Clone();
        }
    }
}
