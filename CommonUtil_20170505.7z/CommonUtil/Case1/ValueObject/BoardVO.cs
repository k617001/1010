﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Case1.ValueObject
{
    public class BoardVO : BaseBoardVO
    {

        public BoardVO()
        {
        }

        public BoardVO(string id, double width, double height)
        {
            this.Width = width;
            this.Height = height;
            this.ID = id;
        }
    }
}
