﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinFormTest.Model.Business
{
    public class ViewImageBO
    {
    }
}
