﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinFormTest.Common;
using WinFormTest.ViewController;
using System.Windows.Forms;

namespace WinFormTest.Register.MenuItem
{
    public class MenuItemReg
    {
        
        /// <summary>
        /// 註冊功能
        /// </summary>
        public static void Register()
        {
            ItemMap itemMap = new ItemMap();
            itemMap
                .RegisterItem<TestItem1>("Item1", "測試")
                .RegisterItem<ImageFolder>("ImageItem", "看圖片")

                ;
        }

        /// <summary>
        /// 取得功能
        /// </summary>
        /// <param name="name"></param>
        public static T GetNewItem<T>(string name)
        {
            return ItemMap.GetNewItem<T>(name);
        }
    }
}
