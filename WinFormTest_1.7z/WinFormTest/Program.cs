﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using WinFormTest.ViewController;
using System.Threading;
using WinFormTest.ExceptionHandle;
using WinFormTest.Register.MenuItem;

namespace WinFormTest
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //錯誤訊息，系統錯誤處理
            Application.ThreadException += new ThreadExceptionEventHandler(EventCatchHandle.ThreadException);

            //註冊功能
            MenuItemReg.Register();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ImageFolder());

        }

    }
}
