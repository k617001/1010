﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using WinFormTest.Common;
using WinFormTest.Enums;
using WinFormTest.ExceptionHandle.CustomException;
using WinFormTest.Model.ControllerView;
using WinFormTest.Config;
using WinFormTest.Common.Resize;

namespace WinFormTest.ViewController
{
    public partial class ImageFolder : Form
    {

        ViewImageCV cv = new ViewImageCV();

        public ImageFolder()
        {
            InitializeComponent();
            //根目錄
            //初始化檔案樹
            string rootPath = SysConfig.ROOT_PATH;
            cv.InitTree(this.treeView, rootPath);

            this.treeView.ExpandAll();
        }

        private void treeView_Click(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeNode node = e.Node;


            //設定image到imageList
            string path = node.FullPath;
            string[] imageFiles = FileUtil.GetFiles(path);

            this.listView1.Items.Clear();
            this.imageList.Images.Clear();

            int i = 0;
            foreach(string imageFile in imageFiles) {
                string filePath = path + "\\" + imageFile;
                this.imageList.Images.Add(filePath, Image.FromFile(filePath));

                this.listView1.Items.Add(imageFile);
                this.listView1.Items[i].ImageIndex = i++;
            }

            

            if (node.GetNodeCount(true) > 0)
            {
                return;
            }

            //展節點
            cv.SetDirTreeNode(node, path);
            this.treeView.ExpandAll();


        }


        /// <summary>
        /// 設定圖片
        /// </summary>
        private void SetImage(Image image, string imageUrl)
        {
            // 實例化 FileStream
            using (FileStream fs = new FileStream(imageUrl, FileMode.Open))
            {
                Byte[] data = new Byte[fs.Length];
                // 把檔案讀取到位元組陣列
                fs.Read(data, 0, data.Length);
                fs.Close();
                // 實例化一個記憶體資料流 MemoryStream，將位元組陣列放入
                using (MemoryStream ms = new MemoryStream(data))
                {
                    // 將記憶體資料流的資料顯示於 PictureBox 中
                    image = Image.FromStream(ms);
                }
            }
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {

        }
    }
}
