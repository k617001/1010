﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinFormTest.Enums
{
    public class TreeImageEnums
    {
        public static int DIRECTORY = 0;
        public static int DIRECTORY_OPEN = 1;
        public static int FILE = 2;
    }
}
