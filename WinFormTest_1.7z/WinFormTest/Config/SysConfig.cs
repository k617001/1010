﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinFormTest.Config
{
    /// <summary>
    /// 系統的config，寫死的資料
    /// </summary>
    public class SysConfig
    {

        public static readonly string ROOT_PATH = @"D:\Test\Images";

        /// <summary>
        /// 副檔名filter
        /// </summary>
        public static readonly string FILTER_FILENAME_EXTENSION = @"jpg";
    }
}
