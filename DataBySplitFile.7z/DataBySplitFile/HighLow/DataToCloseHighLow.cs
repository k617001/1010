﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    public class DataToCloseHighLow
    {
        string filePath = RunAction.TARGET_DIR + @"Day";
        string targetPath = RunAction.TARGET_DIR + @"analysis\MaxMinValue_day.csv";

        StringBuilder content = new StringBuilder();

        MaxMinObj maxMinObj = new MaxMinObj();

        public void Action()
        {
            content.AppendLine(maxMinObj.GetTitle());

            string[] fileNams = Directory.GetFiles(filePath);
            foreach (string fileName in fileNams)
            {
                Console.WriteLine(fileName);
                SetData(fileName);
            }

            ComUtil.Str2File(content.ToString(), targetPath);
            
        }

        private void SetData(string path)
        {

            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                string date = convert.Get<string>("date");
                string time = convert.Get<string>("time");
                string dt = date + " " + (time.Length > 5 ? time : time + ":00");
                DateTime dateTime = Convert.ToDateTime(dt);

                int close = convert.Get<int>("Close");

                maxMinObj.Date = dateTime;
                if (close > maxMinObj.Highest)
                {
                    maxMinObj.Highest = close;
                    maxMinObj.HighestTime = dateTime;
                }
                else if (close < maxMinObj.Lowest)
                {
                    maxMinObj.Lowest = close;
                    maxMinObj.LowestTime = dateTime;
                }
            });

            content.AppendLine(maxMinObj.GetContentAndInit());
        }
    }

    public class MaxMinObj
    {
        public MaxMinObj()
        {
            Init();
        }

        public void Init()
        {
            Date = DateTime.MinValue;
            Highest = -99999999;
            Lowest = 999999999;
            Sub = 0;
        }

        public DateTime Date { set; get; }

        public int Highest { set; get; }

        public DateTime HighestTime { set; get; }

        public int Lowest { set; get; }

        public DateTime LowestTime { set; get; }

        public int Sub { set; get; }

        public string GetTitle()
        {
            return "Date,Highest,HighestTime,Lowest,LowestTime,Sub,up/down, win, lose";
        }

        public string GetContentAndInit()
        {
            int mul = HighestTime > LowestTime ? 1 : -1;
            string content = Date.ToString("yyyy/MM/dd HH:mm:ss")
                + "," + Highest
                + "," + HighestTime.ToString("yyyy/MM/dd HH:mm:ss")
                + "," + Lowest
                + "," + LowestTime.ToString("yyyy/MM/dd HH:mm:ss")
                + "," + (Highest - Lowest) * mul
                + "," + mul
                + "," + (mul > 0 ? 1 : 0)
                + "," + (mul < 0 ? 1 : 0)
                ;
            Init();
            return content;
        }

        /// <summary>
        /// 取得統計
        /// </summary>
        /// <returns></returns>
        public string GetSum()
        {
            return null;
        }
    }

}
