﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 把日漲跌的csv資料，變成js檔，畫成highchart
    /// </summary>
    public class DayReportData
    {
        string filePath = RunAction.TARGET_DIR + @"Day\";
        string targetPath = RunAction.HTML_REPORT_DIR + @"Data\";

        StringBuilder content = new StringBuilder();

        DayObjGroupForChart groupChart = new DayObjGroupForChart();

        public void Action()
        {
            string[] paths = Directory.GetFiles(filePath);

            foreach (string path in paths) 
            {
                this.LoadDayFile(path);
            }
            //寫入至資料js檔案
            ComUtil.CreateDataJsFile("DayReportData", groupChart.Day, targetPath);

        }

        private void LoadDayFile(string path)
        {
            Console.WriteLine(path);
            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                SetGroup(convert, "yyyy-MM-dd", groupChart.Day);
            });
        }

        /// <summary>
        /// 設定群組
        /// </summary>
        /// <param name="convert"></param>
        /// <param name="dateFormat"></param>
        /// <param name="group"></param>
        private void SetGroup(
            CSVLoadConvert convert,
            string dateFormat,
            Dictionary<string, DayObjForChart> groupMap
            )
        {
            string date = convert.Get<string>("date");
            string time = convert.Get<string>("time");
            string dt = date + " " + (time.Length > 5 ? time : time + ":00");
            DateTime dateTime = Convert.ToDateTime(dt);
            string groupName = dateTime.ToString(dateFormat);

            DayObjForChart chartData = null;
            if (!groupMap.ContainsKey(groupName))
            {
                groupMap.Add(groupName, new DayObjForChart());
            }
            chartData = groupMap[groupName];

            chartData.Date.Add(dateTime.ToString("HH:mm"));
            chartData.Close.Add(convert.Get<int>("Close"));
            chartData.Volume.Add(convert.Get<int>("Volume"));
        }


        public class DayObjGroupForChart
        {
            public DayObjGroupForChart()
            {
                Day = new Dictionary<string, DayObjForChart>();
            }

            public Dictionary<string, DayObjForChart> Day { set; get; }
        }

        public class DayObjForChart
        {
            public DayObjForChart()
            {
                Date = new List<string>();
                Close = new List<int>();
                Volume = new List<int>();
            }

            public List<string> Date { set; get; }

            public List<int> Close { set; get; }

            public List<int> Volume { set; get; }
        }
    }
}
