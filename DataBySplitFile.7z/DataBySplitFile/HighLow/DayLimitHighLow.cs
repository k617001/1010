﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 抓當日最高和最低點中所有的資料
    /// </summary>
    public class DayLimitHighLow
    {
        string analysisFilePath = RunAction.TARGET_DIR + @"analysis\MaxMinValue_day.csv";
        string filePath = RunAction.TARGET_DIR + @"Day\";
        string targetPath = RunAction.TARGET_DIR + @"HighLowLimitDay\";

        


        public void Action()
        {
            CSVLoadHelper.LoadCsv(analysisFilePath, (row, convert) =>
            {
                string dateStr = convert.Get<string>("date");
                Console.WriteLine(dateStr);
                if (string.IsNullOrEmpty(dateStr))
                {
                    return;
                }

                string date = convert.Get<DateTime>("date").ToString("yyyy_MM_dd") + ".csv";
                string path = filePath + date;
                SetData(path, convert);
            });
            
        }

        private void SetData(string path, CSVLoadConvert limitConvert)
        {
            
            DateTime date = limitConvert.Get<DateTime>("Date");
            string dateStr = date.ToString("yyyy/MM/dd");

            int highest = limitConvert.Get<int>("Highest");
            DateTime highestTime = limitConvert.Get<DateTime>("HighestTime");
            int lowest = limitConvert.Get<int>("Lowest");
            DateTime lowestTime = limitConvert.Get<DateTime>("LowestTime");

            DateTime sDate = highestTime > lowestTime ? lowestTime : highestTime;
            DateTime eDate = highestTime < lowestTime ? lowestTime : highestTime;


            string title = null;
            StringBuilder content = new StringBuilder();
             CSVLoadHelper.LoadCsv(path, (row, convert) =>
             {
                 if (title == null)
                 {
                     title = convert.GetTitleLine();
                     content.AppendLine(title);
                 }

                 string csvDate = convert.Get<string>("date");
                 string time = convert.Get<string>("time");
                 string dt = csvDate + " " + (time.Length > 5 ? time : time + ":00");
                 DateTime dateTime = Convert.ToDateTime(dt);

                 int close = convert.Get<int>("Close");

                 if (dateTime < sDate || dateTime > eDate)
                 {
                     return;
                 }

                 content.AppendLine(convert.GetDataLine());

             });

             string fileName = date.ToString("yyyy_MM_dd") + ".csv";
             SaveData(targetPath + fileName, content.ToString());
        }

        private void SaveData(string path, string content)
        {
            ComUtil.Str2File(content, path);
        }
    }

}
