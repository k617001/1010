﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 五分鐘學習一次
    /// </summary>
    public class TransMin
    {
        string filePath = RunAction.TARGET_DIR + @"Day\";
        int minute = 5;//每幾分鐘學一次

        //要學習的檔案區間
        DateTime startDay = new DateTime(2015, 1, 5);
        DateTime endDay = new DateTime(2015, 1, 5);

        //換下一個檔案的flag
        bool nextFileFirst = false;


        //總計物件
        TransMinObj trans = new TransMinObj();

        public TransMin(int minute, DateTime startDay, DateTime endDay)
        {
            this.minute = minute;
            this.startDay = startDay;
            this.endDay = endDay;

        }

        public void Action()
        {
            TransMinObj trans = GetTransData();
        }


        public TransMinObj GetTransData()
        {
            for (DateTime day = startDay; endDay >= day; day = day.AddDays(1))
            {
                string dayStr = day.ToString("yyyy_MM_dd") + ".csv";
                string path = filePath + dayStr;
                if (!File.Exists(path))
                {
                    continue;
                }

                this.LoadDayFile(path);
            }

            trans.RemoveEnd();
            return trans;
        }

        private void LoadDayFile(string path)
        {
            int startSave = 1;

            //記錄資料
            List<double> input = new List<double>();

            //幾次要記錄一次的flag
            int inputMax = minute;
            int idalNum = inputMax + 1;
            bool isIdal = false;
            //讀資料
            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                //讀資料至欄位
                double close = convert.Get<double>("Close");


                // 記錄結果-換檔案時下一個第一筆
                if (nextFileFirst)
                {
                    trans.Ideal.Add(close);
                    nextFileFirst = false;
                }

                // 記錄結果
                if (isIdal)
                {
                    trans.Ideal.Add(close);
                    isIdal = false;
                }
                
                if (startSave % inputMax <= inputMax)
                {
                    input.Add(close);
                }

                // 記錄input
                if(startSave >= inputMax && startSave % inputMax == 0) {
                    trans.Input.Add(input);
                    input = new List<double>();
                    isIdal = true;
                }

                startSave++;
            });

            nextFileFirst = true;
        }
    }

    public class TransMinObj
    {
        public TransMinObj()
        {
            Input = new List<List<double>>();
            Ideal = new List<double>();
        }

        public List<List<double>> Input { set; get; }

        public List<double> Ideal { set; get; }

        public void RemoveEnd()
        {
            if (Input.Count > Ideal.Count)
            {
                Input.RemoveAt(Input.Count-1);
            }
        }



        public double[][] TransInputArray()
        {
            double[][] rtnArray = new double[Input.Count][];

            for (int i = 0; i < Input.Count; i++)
            {
                
                List<double> inputValue = Input[i];
                rtnArray[i] = inputValue.Select(s => {
                    int div = Convert.ToInt32("1".PadRight((s * 10).ToString().Length, '0'));
                    return s / div;
                }).ToArray();
            }
            return rtnArray;
        }
        public double[][] TransIdealArray()
        {
            double[][] rtnArray = new double[Ideal.Count][];

            for (int i = 0; i < Ideal.Count; i++)
            {
                int div = Convert.ToInt32("1".PadRight((Ideal[i] * 10).ToString().Length, '0'));
                rtnArray[i] = new double[] { Ideal[i] / div };
            }
            return rtnArray;
        }
    }

}
