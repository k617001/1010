﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Util.ConvertObject;

namespace DataBySplitFile.Common.CSVLoad
{
    /// <summary>
    /// csv資料轉型用
    /// </summary>
    public class CSVLoadConvert
    {
        string[] csvData = null;

        /// <summary>
        /// 取得一整行title
        /// </summary>
        /// <returns></returns>
        public string GetTitleLine()
        {
            return string.Join(",", TitleIdxMapData.Keys);
        }
        /// <summary>
        /// 取得一整行資料
        /// </summary>
        /// <returns></returns>
        public string GetDataLine()
        {
            return string.Join(",", csvData);
        }

        public Dictionary<string, int> TitleIdxMapData {set; get;}

        public void SetData(string[] csvData)
        {
            this.csvData = csvData;
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <typeparam name="T">基本型別，不提供物件型別</typeparam>
        /// <param name="name"></param>
        /// <returns></returns>
        public T Get<T>(string name)
        {
            return ConvertObject.To<T>(this.getData(name));
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private string getData(string name)
        {
            string nameKey = name.ToUpper();
            if (!this.TitleIdxMapData.ContainsKey(nameKey))
            {
                string titleNames = string.Join(", ", TitleIdxMapData.Keys.ToArray());
                throw new Exception("csv無此定義的title名稱 => " + nameKey + "(" + titleNames + ")");
            }

            int titleIdx = this.TitleIdxMapData[nameKey];
            return this.csvData[titleIdx];
        }
    }
}
