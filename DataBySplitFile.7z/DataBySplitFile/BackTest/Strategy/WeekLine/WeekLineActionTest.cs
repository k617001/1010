﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using ConsoleTest.DataBySplitFile.BackTest.WeekLine.WeekLineAction;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using System.IO;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine
{
    public class WeekLineActionTest
    {
        public void Action()
        {
            ProductInfoVO productVO = new ProductInfoVO()
            {
                NameId = "TX",
                NickName = "TX",
                Name = "TX",
                Fee = 100,
                PointMoney = 50,
                StopLosePointParcent = 98, //小於n%賣出
            };

            
            //查詢要測試的資料
            Avg7DayData dataObj = new Avg7DayData();
            List<DailyAverageEntity> dataList = dataObj.FindAll(null);

            WeekLineAction action = new WeekLineAction(productVO);
            action.Clear();
            foreach (DailyAverageEntity entity in dataList)
            {
                action.StrategyAction(new NowDataVO()
                { 
                    Date = entity.DateTime, 
                    Close = entity.Close
                });
            }

        }
    }
}
