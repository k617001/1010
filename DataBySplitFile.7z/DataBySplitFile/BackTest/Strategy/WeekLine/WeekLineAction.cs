﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.Base;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using ConsoleTest.DataBySplitFile.BackTest.Enums;

namespace ConsoleTest.DataBySplitFile.BackTest.WeekLine.WeekLineAction
{
    /// <summary>
    /// 週線
    /// </summary>
    public class WeekLineAction 
    {
        int day = 7;

        ProductInfoVO productVO = null;
        Avg7DayData avg7DayData = new Avg7DayData();
        Buy7DayData buyData = null;
        Sell7DayData SellData = null;

        public WeekLineAction(ProductInfoVO productVO)
        {
            this.productVO = productVO;
            this.buyData = new Buy7DayData(productVO);
            this.SellData = new Sell7DayData(productVO);
        }

        public void StrategyAction(NowDataVO data)
        {
            Console.WriteLine(data.Date.ToShortDateString());
            //取得均線資料
            DailyAverageEntity weekAvg = avg7DayData.GetDayAverage(data.Close, day, data.Date);
            DailyAverageEntity beforeClose = avg7DayData.GetBeforeData(data.Date);
            List<BuyVO> ownData = this.MyOwn();

            if (beforeClose == null)
            {
                return;
            }

            //停損點判斷
            if (ownData.Count > 0 && ownData[0].StopLosePoint >= data.Close)
            {
                Sell(data, ownData, weekAvg, beforeClose);
            }

            if (beforeClose.Close >= weekAvg.Average && weekAvg.Average >= data.Close)
            {
                if (ownData != null)
                {
                    Sell(data, ownData, weekAvg, beforeClose);
                }
                //判斷做多/做空，買進
                int type = BuyTypeEnum.EMPTY;
                Buy(data, type);
            }

            //交叉的判斷
            else if (beforeClose.Close <= weekAvg.Average && weekAvg.Average <= data.Close)
            {
                //如果有買進的資料，則賣掉
                if (ownData != null)
                {
                    Sell(data, ownData, weekAvg, beforeClose);
                }

                //判斷做多/做空，買進
                int type = BuyTypeEnum.EMPTY;
                if (data.Close > beforeClose.Close) //今>昨 漲，做多
                {
                    type = BuyTypeEnum.MULTI;
                    Buy(data, type);
                }
                else
                {
                }

            }
        }

        /// <summary>
        /// 清空資料，測試用
        /// </summary>
        public void Clear()
        {
            this.buyData.DeleteAll();
            this.SellData.DeleteAll();
        }

        /// <summary>
        /// 買
        /// </summary>
        /// <param name="data"></param>
        /// <param name="type"></param>
        private void Buy(NowDataVO data, int type)
        {
            BuyVO buyData = new BuyVO()
            {
                BackTestId = Guid.NewGuid(),
                Point = data.Close,
                Date = data.Date,
                Type = type,
                StopLosePoint = (int)(data.Close * (this.productVO.StopLosePointParcent / 100.0)),
                ProductInfoVO = this.productVO,
                Selled = "N"
            };

            this.buyData.Insert(buyData);
        }

        /// <summary>
        /// 賣
        /// </summary>
        /// <param name="nowData"></param>
        /// <param name="ownData"></param>
        /// <param name="weekAvg"></param>
        /// <param name="beforeClose"></param>
        private void Sell(NowDataVO nowData, List<BuyVO> ownData, DailyAverageEntity weekAvg, DailyAverageEntity beforeClose)
        {
            //更新買的狀態
            this.buyData.UpdateSelled(ownData);


            SellVO sellVO = new SellVO()
            {
                ProductInfoVO = this.productVO,
                SellDate = nowData.Date,
                BuyVOs = ownData,
                Point = nowData.Close
            };

            SellData.Insert(sellVO);
        }

        /// <summary>
        /// 查詢目前未賣掉的資料
        /// </summary>
        /// <returns></returns>
        private List<BuyVO> MyOwn()
        {
            return this.buyData.FindAll(f => "N".Equals(f.Selled));
        }
    }

}
