﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.Enums;

namespace ConsoleTest.DataBySplitFile.BackTest.ValueObject
{
    public class BuyVO
    {
        /// <summary>
        /// 做空或做多
        /// </summary>
        public int Type { set; get; }
        public Guid BackTestId { set; get; }
        public string ID1 { set; get; }
        public string ID2 { set; get; }
        public int Point { set; get; }
        public int Money { get {
            return Point * ProductInfoVO.PointMoney;
        }
        }
        public int StopLosePoint { set; get; }
        /// <summary>
        /// Y or N
        /// </summary>
        public string Selled { set; get; }
        public DateTime Date { set; get; }

        public ProductInfoVO ProductInfoVO { set; get; }

    }
}
