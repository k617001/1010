﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile.BackTest.ValueObject
{
    public class NowDataVO
    {
        public int Close { set; get; }
        public DateTime Date { set; get; }
    }
}
